--------------------------------------------------------------------------------
This folder accompanies the paper "The Impact of Abortion Legalization on Fertil
ity and Female Empowerment: New Evidence from Mexico" by Clarke and Muhlrad.  It
includes source legal documents from each state defining the date of constitutio
nal reforms to abortion laws in Mexico between April 2007 and December 2009.  Ea
ch decree or law change is saved as a pdf file of the scanned original document,
and is named according to the State's name.  Further details are available in th
e paper, or contacting damian.clarke@usach.cl.
