README FOR GENERAL TO SPECIFIC MODELLING USING STATA
2013-08-17
Damian Clarke

This folder contains 3 program files and two data files.  
The three program files are a stata ado file of the general
to specific algorithm (gets.ado), a help file for this
ado (gets.sthlp) and a do file to run the simulations 
described in table 1 of the Paper.

Two data files are also included.  In order to replicate
table 1 the data, the file gets_data.dta should be used. The
raw data discussed in Appendix 1 of the paper and in Hoover
and Perez (1999) is included as gets_raw_data.dta if desired.

In case of any queries about the above program files, 
contact damian.clarke@economics.ox.ac.uk
 