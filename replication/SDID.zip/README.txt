Note: "README.txt" file for a Stata Journal software submission. 
-------------------------------------------------------------------------------

Package name:  Article tag (Stata Press to add)

DOI:  Digital object identifier (Stata Press to add)

Title: Synthetic Difference In Differences Estimation

Author 1 name:  Damian Clarke
Author 1 from:  Department of Economics, University of Chile, Chile
Author 1 email: dclarke@fen.uchile.cl

Author 2 name:  Daniel Pailañir
Author 2 from:  Department of Economics, University of Chile, Chile
Author 2 email: dpailanir@fen.uchile.cl

Author 3 name:  Susan Athey
Author 3 from:  Graduate School of Business, Stanford University, USA
Author 3 email: athey@stanford.edu

Author 4 name:  Guido Imbens
Author 4 from:  Graduate School of Business, Stanford University, USA
Author 4 email: imbens@stanford.edu

Help keywords: sdid "sdid"

File list: sdid.ado sdid.sthlp
