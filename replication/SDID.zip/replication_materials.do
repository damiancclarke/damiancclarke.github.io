/* SDID_paper_replication.do                               yyyy-mm-dd:2024-01-07
*----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8
    This code is to replicate the estimation and results of:
        "On Synthetic Difference-in-Differences and
             Related Estimation Methods in Stata"
		
    Requirements: install sdid command using one of the following codes:
	
    - ssc install sdid, replace
    - net install sdid, from("https://raw.githubusercontent.com/daniel-pailanir/sdid/master") replace

This code also requires the esto routines of Ben Jann.  Please ensure that these
are installed from the SSC (ssc install estout).
*/

log using replication_sdid, replace text

capture which eststo
if _rc!=0 dis as warning "Estout routines required for replication.  These can be installed using ssc install estout"

clear all
set more off

*------------------------------------------------------------------------------
* 4.1 A block design
*------------------------------------------------------------------------------
webuse set www.damianclarke.net/stata/
webuse prop99_example.dta, clear
sdid packspercapita state year treated, vce(placebo) seed(1213)

* Save the graph in figure 2 panel (b) (e)
#delimit ;
sdid packspercapita state year treated, method(did) vce(noinference) graph msize(small)
    g1_opt(ylabel(-110(20)50) xtitle("") scheme(sj)) g1on
    g2_opt(ylabel(0(25)150) ytitle("Packs per capita") scheme(sj))
    graph_export(did_, .pdf);
#delimit cr

* Save the graph in figure 2 panel (c) (f)
#delimit ;
sdid packspercapita state year treated, method(sc) vce(noinference) graph
    g1_opt(ylabel(-110(20)50) xtitle("") scheme(sj)) g1on
    g2_opt(ylabel(0(25)150) ytitle("Packs per capita") scheme(sj))
    graph_export(sc_, .pdf);
#delimit cr

* Save the graph in figure 1 and figure 2 panel (a) (d)
#delimit ;
sdid packspercapita state year treated, method(sdid) vce(noinference) graph
    g1_opt(ylabel(-110(20)50) xtitle("") scheme(sj)) g1on
    g2_opt(ylabel(0(25)150) ytitle("Packs per capita") scheme(sj))
    graph_export(sdid_, .pdf);
#delimit cr

* Save the graph in figure 3
preserve
clear
matrix series = e(series)
matrix lambda = e(lambda)
qui svmat series, names(col)
qui svmat lambda

#delimit ;
tw line Yco1989 year, yaxis(1) || 
    line Ytr1989 year, yaxis(1) || 
    area lambda1 year if year<=1988, yaxis(2) ylabel(0(1)5, axis(2)) yscale(off axis(2)) || 
    , legend(order(1 "Control" 2 "Treated") pos(12) col(2))
    xline(1989, lc(red)) scheme(sj);
graph export sdid_replicate.pdf, replace;
#delimit cr
restore

*------------------------------------------------------------------------------
* 4.2 A Staggered Adoption Design
*------------------------------------------------------------------------------
webuse quota_example.dta, clear
lab var quota "Parliamentary Gender Quota"

eststo sdid_1: sdid womparl country year quota, vce(bootstrap) seed(1213)
matlist e(tau)

* With covariates
preserve
drop if lngdp==.
eststo sdid_2: sdid womparl country year quota, vce(bootstrap) seed(1213) covariates(lngdp)

* Projected way
eststo sdid_3: sdid womparl country year quota, vce(bootstrap) seed(1213) covariates(lngdp, projected)
restore

* Export table 1
#delimit ;
esttab sdid_1 sdid_2 sdid_3 using "example1.tex", starlevel ("*" 0.10 "**" 0.05 "***" 0.01) b(%-9.3f) 
    se(%-9.3f) style(tex) replace
    stats(N , labels("Observations") fmt(%9.0fc))
    nonotes addnotes("* p$<$0.10, ** p$<$0.05, *** p$<$0.01");
#delimit cr

*-------------------------------------------------------------------------------
* 4.3 Inference Options
*-------------------------------------------------------------------------------
webuse quota_example.dta, clear

#delimit ;
drop if country=="Algeria" | country=="Kenya" | country=="Samoa" | 
        country=="Swaziland" | country=="Tanzania";
#delimit cr

* Bootstrap
sdid womparl country year quota, vce(bootstrap) seed(1213)

* Placebo
sdid womparl country year quota, vce(placebo) seed(1213)

* Jackknife
sdid womparl country year quota, vce(jackknife)                   

*-------------------------------------------------------------------------------
* 4.4 Event Study Style Output
*-------------------------------------------------------------------------------
webuse quota_example.dta, clear

egen m = min(year) if quota==1, by(country) // indicator for the year of adoption
egen mm = mean(m), by(country)
keep if mm==2002 | mm==.                    // keep only one time of adoption
drop if lngdp==.                            //keep if covariates observed

* Estimation and save figure 4 panel (a)
#delimit ;
sdid womparl country year quota, vce(noinference) covariates(lngdp, projected)
    graph g2_opt(ylab(-5(5)20) ytitle("Women in Parliament") scheme(sj)) 
    graph_export(groups, .pdf);
#delimit cr

matrix lambda = e(lambda)[1..12,1]     // save lambda weight
matrix yco = e(series)[1..12,2]        // control baseline
matrix ytr = e(series)[1..12,3]        // treated baseline
matrix aux = -lambda'*(ytr - yco)      // calculate the pre-treatment mean
scalar meanpre_o = aux[1,1]    

matrix difference = e(difference)[1..26,1..2]
svmat difference
ren (difference1 difference2) (time d)
replace d = d + meanpre_o

local b = 1
local B = 100
while `b'<=`B' {
    preserve
    bsample, cluster(country) idcluster(c2)
    qui count if quota == 0
    local r1 = r(N)
    qui count if quota != 0
    local r2 = r(N)    
    if (`r1'!=0 & `r2'!=0) {
        display in smcl "." _continue
        if mod(`b',50)==0 dis "     `b'"
        qui sdid womparl c2 year quota, vce(noinference) graph covariates(lngdp, projected)
		
        matrix lambda_b = e(lambda)[1..12,1]       // save lambda weight
        matrix yco_b = e(series)[1..12,2]          // control baseline
        matrix ytr_b = e(series)[1..12,3]          // treated baseline
        matrix aux_b = -lambda_b'*(ytr_b - yco_b)  // calculate the pre-treatment mean
        matrix meanpre_b = J(26,1,aux_b[1,1])
		
        matrix d`b' = e(difference)[1..26,2] + meanpre_b // store the difference series
		
        local ++b
    }
    restore
}
	
preserve
keep time d
keep if time!=.

forval b=1/`B' {
    svmat d`b'
}

egen rsd = rowsd(d11-d`B'1)        // calculate standar deviation
gen LCI = d + invnormal(0.025)*rsd // lower bounds
gen UCI = d - invnormal(0.025)*rsd // upper bounds

* Firgure 4 panel (b)
#delimit ;
tw rarea UCI LCI time, color(gray%40) || scatter d time, color(blue) m(d) ||, 
    xtitle("") ytitle("Women in Parliament") xlab(1990(1)2015, angle(45))
    legend(order(2 "Point Estimate" 1 "95% CI") pos(12) col(2)) 
    xline(2002, lc(black) lp(solid)) yline(0, lc(red) lp(shortdash)) scheme(sj);
graph export "event_sdid.pdf", replace;
#delimit cr
restore

*-------------------------------------------------------------------------------
* 4.5 Other Parameters
*-------------------------------------------------------------------------------
webuse set www.damianclarke.net/stata/
webuse prop99_example.dta, clear
sdid packspercapita state year treated, vce(noinference) returnweights 
gen weight = lambda*omega

encode state, gen(st)
reg packspercapita treated i.st i.year [aw=weight]
drop lambda omega weight

//Taus will be used to store permutation estimates
gen Taus = .
local B=50
set seed 1213
forvalues b=1/`B' {
    preserve
    qui {
        //Drop treatment state 
        drop if state=="California"
        //Permute treatment to one untreated state using highest value of random draw
        gen draw = rnormal()
        bys state: replace draw = draw[1]
        sum draw
        gen treat = draw == r(max) & year>=1989

        //Estimate sdid based on permuted treatment and return weights
        sdid packspercapita state year treat, vce(noinference) returnweights    
        gen weight = lambda*omega
        
        //Estimate regression based version which also returns FEs
        reg packspercapita treat i.st i.year [aw=weight]
    }
    restore
    qui replace Taus = _b[treat] in `b'
}
sum Taus

*-------------------------------------------------------------------------------
* A2 Replicating Weight Graphs
*-------------------------------------------------------------------------------
webuse prop99_example.dta, clear

#delimit ;
sdid packspercapita state year treated, vce(placebo) seed(1213) reps(5) graph 
     g1_opt(xtitle("") scheme()) g2_opt(ylabel(0(25)150) ytitle("Packs per capita"))
	 mattitles returnweights;
#delimit cr

bys state: egen y1=mean(packspercapita) if year>=1989
bys state: egen y2=mean(packspercapita*lambda) if year<=1988
replace y2=y2*19
egen ypost=mean(y1), by(state)
egen ypre=mean(y2), by(state)
keep state ypre ypost omega
duplicates drop
gen delta=ypost-ypre
qui sum delta if state=="California"
gen sdelta=`r(mean)'
gen difference=sdelta-delta
egen id=group(state)
replace omega=. if state=="California"
drop if omega==.
encode state, gen(state2) l(id)

* Figure A1
#delimit ;
tw scatter difference state2 if omega!=0 [aw=omega], msize(tiny) || 
   scatter difference state2 if omega==0, m(X) 
   xlabel(1(1)38, angle(vertical) labs(vsmall) valuelabel)
   yline(-15.60383, lc(red)) legend(off) xtitle("")
   ytitle("Difference") scheme(sj);
graph export "sdid_panela.pdf", replace;
#delimit cr

log close

exit, clear
