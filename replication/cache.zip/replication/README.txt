--------------------------------------------------------------------------------
Replication Materials: 
  cacheit: A Generalized Mechanism for Storing and Replaying Any Stata Command
  R Andrés Castañeda and Damian Clarke
  February, 2026
--------------------------------------------------------------------------------

This folder contains replication materials for the paper "cacheit: A Generalized 
Mechanism for Storing and Replaying Any Stata Command" published in the Stata 
Journal. The folder contains eight files apart from this README file:
 - cacheit.ado: The main ado described in the paper
 - cacheit.sthlp: Documentation for this program
 - cacheit_clean.ado: Auxiliary ado for use with cache.ado
 - cacheit_hash.ado: Auxiliary ado for use with cache.ado
 - cache_list.ado: Auxiliary ado for use with cache.ado
 - cacheit_examples.ado: Auxiliary ado for use with cache.sthlp
 - cacheit_replication.do: Replication of all the materials in the paper
 - cacheit_replication.txt: Output (log file) from running cacheit_replication.do 

To replicate the results documented in the paper, simply run the file
cacheit_replication.do in Stata (version >=16.0).  This ado requires a number
of additional programs which can be installed directly from the SSC, namely:
> frameappend
> sdid
Additionally, sjlog is used from the sjlatex programme.  This can be installed as:
> net from http://www.stata-journal.com/production/
> net install sjlatex
See also details here: https://www.stata-journal.com/author/

If these are not available on the system where this script is located, they
should be installed prior to running the do file.  This will be checked in the 
file cacheit_replication.do

The replication materials will generate a Figure which is included in the manuscript
(whengain.pdf).  All other required outputs are generated in the log file.

Running this replication file should take around 20 minutes on a computer with 
8GB of RAM.

In case of queries, please contact:
 dclarke@fen.uchile.cl

