/* cacheit_replication.do R Andrés Castañeda/Damian Clarke yyyy-mm-dd:2025-05-22
----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8
  
  This program replicates all results documented in the paper:
  cacheit: A Generalized Mechanism for Storing and Replaying Any Stata Command

  This requires the following two user-written ados, which are searched and ins-
  talled if not available:
    - frameappend
	- sdid
  Additionally, it requires the sjlog command, which can be installed as follows	
    net from http://www.stata-journal.com/production/
    net install sjlatex
	
  To replicate code, simply run this do file.  If this has been previously run,
  to conserve future behaviour, "cacheit clean" should be run to start with an 
  empty cache.
  
  Queries can be directed to dclarke@fen.uchile.cl.
  
*/

vers 16
clear all
set more off
cap log close

log using cacheit_replication.txt, text replace

*-------------------------------------------------------------------------------
*--- (0) Check for external ados and log
*-------------------------------------------------------------------------------
cap which sdid
if _rc!= 0 ssc install sdid
cap which frameappend
if _rc!= 0 ssc install frameappend


*-------------------------------------------------------------------------------
*--- (1) A simple illustration (section 4.1)
*-------------------------------------------------------------------------------
sysuse auto
cacheit: reg price weight length if foreign==0

return list
ereturn list
sreturn list

sum price
return list

cacheit: reg price weight length if foreign==0
return list
ereturn list
sreturn list

count if e(sample)==1
tab foreign if e(sample)==1


*-------------------------------------------------------------------------------
*--- (2) An illustration of potential time-savings (section 4.2)
*-------------------------------------------------------------------------------
sysuse auto, clear
timer on 1
cacheit: bootstrap, reps(10000) dots(500): reg price mpg
timer off 1
timer list

timer on 2
cacheit: bootstrap, reps(10000) dots(500): reg price mpg
timer off 2
timer list


*-------------------------------------------------------------------------------
*--- (3) Saving and accessing other elements (section 4.3)
*-------------------------------------------------------------------------------
webuse set www.damianclarke.net/stata/
webuse prop99_example.dta, clear
cacheit: sdid packspercapita state year treated, vce(placebo) seed(1213) graph g1on

graph dir

graph drop _all
cacheit: sdid packspercapita state year treated, vce(placebo) seed(1213) graph g1on

graph dir


*-------------------------------------------------------------------------------
*--- (4) Caching with commands using external data files or frames (section 4.4)
*-------------------------------------------------------------------------------
clear 
set obs 10
gen ID = _n

gen var1 = rnormal()
save myFile1.dta, replace

drop var1
gen var2 = rnormal()
save myFile2.dta, replace


clear
use myFile1
cacheit: merge 1:1 ID using myFile2
describe

use myFile2
gen var3 = rnormal()
save myFile2.dta, replace

use myFile1
cacheit: merge 1:1 ID using myFile2

ds

use myFile1
cacheit, datacheck(myFile2): merge 1:1 ID using myFile2
ds

clear all
frame create frame1
frame create frame2
 
set seed 121316
cwf frame1
set obs 10
gen randnoise = rnormal()

cwf frame2
set obs 10
gen randnoise = rnormal()

cwf frame1
cacheit: frameappend frame2

clear all
frame create frame1
frame create frame2

set seed 121316
cwf frame1
set obs 10
gen randnoise = rnormal()

cwf frame2
set obs 20
gen randnoise = rnormal()

cwf frame1
preserve
cacheit: frameappend frame2
count

restore
cacheit, framecheck(frame2): frameappend frame2
count

*-------------------------------------------------------------------------------
*--- (5) Use of cacheit sub-commands (section 4.5)
*-------------------------------------------------------------------------------
cacheit list
*cacheit clean
*cacheit list

log close


*-------------------------------------------------------------------------------
*--- (6) When can users gain from cacheit?
*-------------------------------------------------------------------------------
sjlog using whengain, replace
clear all

mat def times = J(28,7,.)

local j = 1
foreach o of numlist 1000(1000)9000 10000(10000)100000 200000(100000)1000000 {

	qui {
		set obs `o'

		gen y = rnormal()
		gen y1 = y>0
		foreach num of numlist 1(1)10 {
			gen x`num' = rnormal()
		}
		// SUM
		cacheit: sum y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
	
		timer on 1
		sum y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer off 1

		timer on 2
		cacheit: sum y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer off 2
	

		// PROBIT
		cacheit: probit y1 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer on 3
		probit y1 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer off 3

		timer on 4
		cacheit: probit y1 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer off 4
	
	
		// BOOTSTRAP
		cacheit: reg y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10, vce(bootstrap)
		timer on 5
		reg y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10, vce(bootstrap)
		timer off 5

		timer on 6
		cacheit: reg y x1 x2 x3 x4 x5 x6 x7 x8 x9 x10, vce(bootstrap)
		timer off 6
	
		timer list
		mat times[`j',1]=r(t1)
		mat times[`j',2]=r(t2)
		mat times[`j',3]=r(t3)
		mat times[`j',4]=r(t4)
		mat times[`j',5]=r(t5)
		mat times[`j',6]=r(t6)
	
		mat times[`j',7]=`o'
		drop y y1 x1 x2 x3 x4 x5 x6 x7 x8 x9 x10
		timer clear
		local ++j
	}
}

svmat times

gen reltimeSum = times2/times1
gen reltimePro = times4/times3
gen reltimeBSt = times6/times5


rename times7 numobs
replace numobs = numobs/1000

twoway line reltimePro numobs, yaxis(1) ///
    || line reltimeBSt numobs, yaxis(1) ///
	|| line reltimeSum numobs, yaxis(2) ///
scheme(sj) ytitle("Relative Time")      ///
ytitle("Relative Time (Summarize command)", axis(2)) ///
xtitle("Observations (1000s)") yline(1) ///
legend(order(1 "Probit" 2 "Bootstrap" 3 "Summarize (right axis)") row(1))
graph export whengain.pdf, replace
sjlog close, replace





