The code in this folder calculates the frequency of mentions of
the word "fertility" in title names of articles in the Journal
of Political Economy, as outlined in end note 1 of the paper. In
order to replicate these calculations run scrapeJPE.py using any
Python version 2 release, and type:

  python scrapeJPE.py


