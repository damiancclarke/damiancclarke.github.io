--------------------------------------------------------------------------------
README for "The Romano-Wolf Multiple Hypothesis Correction in Stata"
Damian Clarke, Joseph P. Romano & Michael Wolf
--------------------------------------------------------------------------------

This folder contains four sub-directories:
|_ data:    contains all data used in the paper
|_ source:  contains all source code used for replication of results
|_ results: tables and figures provided in the paper
|_ log:     a log file produced when running each piece of source code

All results in the paper can be replicated by running the programs provided in
the "source" sub-directory, simply changing the global variables in the header
of each do file to pointing to the location of these folders on your computer.
All source files are written for Stata version >=11.0.

The following list indicates the files in the "source" directory, and their
correspondence to results in the paper:
  - simulationsSize.do  : Table 1
  - simulationsPower.do : Figure 1
  - SATanalysis.do      : Examples in section 4.2 and Figure 3
  - paperSnippets.do    : Examples on pp. 12-13, 17, 18 and Figure 2.

Additionally, the file rwolf.ado is used in each file, and implements the
Romano-Wolf multiple hypothesis correction discussed in this paper.

For queries contact Damian Clarke at

  damian.clarke [AT] usach.cl

or

  damian.clarke [AT] protonmail.com.
  
