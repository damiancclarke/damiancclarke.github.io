global DAT "/home/damian/investigacion/2019/multHypRWolf/replication/data"
global LOG "/home/damian/investigacion/2019/multHypRWolf/replication/log"
global OUT "/home/damian/investigacion/2019/multHypRWolf/replication/results"

*-------------------------------------------------------------------------------
*--- (1) Bootstrap example of RW/WY data
*-------------------------------------------------------------------------------
sjlog using "$LOG/RWWYBSex1", replace
use "SATgenerated", clear
set seed 13032019
local var1 satdev salary black satdev satdev ratio ratio satdev salary ratio
local var2 black crime crime ratio crime crime black salary black salary

tokenize `var2'
local i=1
foreach var of varlist `var1' {
    qui reg `var' ``i''
    local c`i'=_b[``i'']
    local s`i'=_se[``i'']
    local ++i
}

foreach num of numlist 1/10 {
    qui gen rho`num'=.
    qui gen std`num'=.
}

sjlog close, replace


sjlog using "$LOG/RWWYBSex2", replace
local N=5000
set obs `N'
forvalues n=1/`N' {
    preserve
    qui keep if sat!=.
    bsample 
    tokenize `var2'
    local xvar=1
    foreach var of varlist `var1' {
        qui reg `var' ``xvar''
        local bta`xvar' = _b[``xvar'']
        local std`xvar' =_se[``xvar'']
        local ++xvar
    }
    restore
    foreach num of numlist 1/10 {
        qui replace rho`num'=`bta`num'' in `n'
        qui replace std`num'=`std`num'' in `n'
    }
}
sjlog close, replace

sjlog using $LOG/RWWYBSex3, replace
local allcorrs `c1' `c2' `c3' `c4' `c5' `c6' `c7' `c8' `c9' `c10'
local allserrs `s1' `s2' `s3' `s4' `s5' `s6' `s7' `s8' `s9' `s10'

sjlog using ../paper/RWWYex2, replace
lab var bsatdevblack "SAT deviation - % Black"
lab var bsalarycrime "Teacher salary - Crime"
lab var bblackcrime  "% Black - Crime"
lab var bsatdevratio  "Sat deviation - S/T ratio"
lab var bsatdevcrime  "Sat deviation - Crime"
lab var bratiocrime   "S/T ratio - Crime"
lab var bratioblack   "S/T ratio - % Black"
lab var bsatdevsalary "Sat dev. - Teacher salary"
lab var bsalaryblack  "Teacher salary - % Black"
lab var bratiosalary  "S/T ratio - Teacher salary"


#delimit ;
rwolf rho1 rho2 rho3 rho4 rho5 rho6 rho7 rho8 rho9 rho10,
nobootstraps stdests(std1 std2 std3 std4 std5 std6 std7 std8 std9 std10)
pointestimates(`allcorrs') stderrs(`allserrs') graph noplusone varlabels;
#delimit cr
sjlog close, replace
graph export "$OUT/corrtests.eps", replace

