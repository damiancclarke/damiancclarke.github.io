global DAT "/home/damian/investigacion/2019/multHypRWolf/replication/data"
global LOG "/home/damian/investigacion/2019/multHypRWolf/replication/log"
global OUT "/home/damian/investigacion/2019/multHypRWolf/replication/results"

*-------------------------------------------------------------------------------
*--- (1) Bootstrap example of RW/WY data
*-------------------------------------------------------------------------------
sjlog using "$LOG/RWWYBSex1_rho", replace
use "$DAT/SATgenerated", clear
set seed 13032019
local var1 satdev salary black satdev satdev ratio ratio satdev salary ratio
local var2 black crime crime ratio crime crime black salary black salary

tokenize `var2'
local i=1
foreach var of varlist `var1' {
    qui corr `var' ``i''
    local c`i'=r(rho)
    local s`i'=sqrt((1-r(rho)^2)/(r(N)-2))
    local ++i
}

foreach num of numlist 1/10 {
    qui gen rho`num'=.
    qui gen std`num'=.
}

sjlog close, replace


sjlog using "$LOG/RWWYBSex2_rho", replace
local M=5000
set obs `M'
forvalues m=1/`M' {
    preserve
    qui keep if sat!=.
    bsample 
    tokenize `var2'
    local s=1
    foreach var of varlist `var1' {
        qui corr `var' ``s''
        local cor`s' = r(rho)
        local std`s' = sqrt((1-r(rho)^2)/(r(N)-2))
        local ++s
    }
    restore
    foreach s of numlist 1/10 {
        qui replace rho`s'=`cor`s'' in `m'
        qui replace std`s'=`std`s'' in `m'
    }
}
sjlog close, replace

sjlog using "$LOG/RWWYBSex3_rho", replace
local allcorrs `c1' `c2' `c3' `c4' `c5' `c6' `c7' `c8' `c9' `c10'
local allserrs `s1' `s2' `s3' `s4' `s5' `s6' `s7' `s8' `s9' `s10'

lab var csatdevblack "SAT deviation - % Black"
lab var csalarycrime "Teacher salary - Crime"
lab var cblackcrime  "% Black - Crime"
lab var csatdevratio  "Sat deviation - S/T ratio"
lab var csatdevcrime  "Sat deviation - Crime"
lab var cratiocrime   "S/T ratio - Crime"
lab var cratioblack   "S/T ratio - % Black"
lab var csatdevsalary "Sat dev. - Teacher salary"
lab var csalaryblack  "Teacher salary - % Black"
lab var cratiosalary  "S/T ratio - Teacher salary"

#delimit ;
rwolf rho1 rho2 rho3 rho4 rho5 rho6 rho7 rho8 rho9 rho10,
nobootstraps stdests(std1 std2 std3 std4 std5 std6 std7 std8 std9 std10)
pointestimates(`allcorrs') stderrs(`allserrs') graph noplusone varlabels;
#delimit cr
sjlog close, replace
graph export "$OUT/corrtests_rho.eps", replace
