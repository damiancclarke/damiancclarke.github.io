global DAT "/home/damian/investigacion/2019/multHypRWolf/replication/data"
global LOG "/home/damian/investigacion/2019/multHypRWolf/replication/log"
global OUT "/home/damian/investigacion/2019/multHypRWolf/replication/results"


set seed 130319
clear
sjlog using "$LOG/simulations1", replace

set obs 100
gen treat  = runiform()>0.5
foreach num of numlist 1(1)10 {
    gen c`num'     = rnormal()
}
local r=0.25
#delimit ;
mat corr   = (1,`r',`r',`r',`r',`r',`r',`r',`r',`r' \
              `r',1,`r',`r',`r',`r',`r',`r',`r',`r' \
              `r',`r',1,`r',`r',`r',`r',`r',`r',`r' \
              `r',`r',`r',1,`r',`r',`r',`r',`r',`r' \
              `r',`r',`r',`r',1,`r',`r',`r',`r',`r' \
              `r',`r',`r',`r',`r',1,`r',`r',`r',`r' \
              `r',`r',`r',`r',`r',`r',1,`r',`r',`r' \
              `r',`r',`r',`r',`r',`r',`r',1,`r',`r' \
              `r',`r',`r',`r',`r',`r',`r',`r',1,`r' \
              `r',`r',`r',`r',`r',`r',`r',`r',`r',1);
#delimit cr
mat corsim = cholesky(corr)

foreach num of numlist 1(1)10 {
    matrix eps`num' = corsim[`num',1..10]
    matrix score epsilon`num' = eps`num'
    gen y`num' = 1 + 0*treat + epsilon`num'
}

rwolf y1 y2 y3 y4 y5 y6 y7 y8 y9 y10, indepvar(treat) reps(1000) nodots holm
sjlog close, replace


set seed 120113031
sjlog using "$LOG/IVmodelA", replace
use http://www.stata-press.com/data/r13/hsng, clear
rwolf rent popden popgrow hsng, indepvar(hsngval) method(ivregress) /*
 */ iv(faminc i.region) reps(10000) graph nodots                    /*
 */ controls(pcturban)
sjlog close, replace
graph export "$OUT/IV2sided.eps", replace
set seed 120113031

sjlog using "$LOG/IVmodelB", replace
replace popden=-popden
replace hsng  =-hsng
rwolf rent popden popgrow hsng, indepvar(hsngval) method(ivregress)  /*
 */ iv(faminc i.region) reps(10000) graph onesided(negative) nodots  /*
 */  controls(pcturban)
sjlog close, replace
graph export "$OUT/IV1sided.eps", replace

