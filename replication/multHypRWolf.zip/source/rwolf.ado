*! rwolf: Romano Wolf stepdown hypothesis testing algorithm
*! Version 2.2.0 june 2, 2018 @ 21:17:21
*! Author: Damian Clarke
*! Department of Economics
*! Universidad de Santiago de Chile
*! damian.clarke@usach.cl

/*
version highlights:
1.0.0 [01/12/2016]: Romano Wolf Procedure exporting p-values
1.1.0:[23/07/2017]: Experimental weighting procedure within bootstrap to allow weights
2.0.0:[16/10/2017]: bsample exclusively.  Add cluster and strata for bsample
2.1.0:[15/12/2017]: Adding ivregress as permitted method.
2.2.0:[29/05/2018]: Correcting estimate of standard error in studentized t-value
*/

/*
TODO:
*/

cap program drop rwolf
program rwolf, eclass
vers 11.0
#delimit ;
syntax varlist(min=1 fv ts numeric) [if] [in] [pweight fweight aweight iweight],
[
 indepvar(varlist max=1)
 method(name)
 NOBOOTstraps           
 pointestimates(numlist)
 stderrs(numlist)
 stdests(varlist min=1)
 controls(varlist fv ts)
 seed(numlist integer >0 max=1)
 reps(integer 100)
 Verbose
 strata(varlist)
 otherendog(varlist)
 cluster(varlist)
 iv(varlist fv ts) 
 indepexog
 bl(name)
 onesided(name)
 noplusone
 graph
 nullimposed
 varlabels
 nodots
 holm
 nulls(numlist)
 *
 ]
;

#delimit cr
cap set seed `seed'
if `"`method'"'=="" local method regress
if `"`method'"'=="ivreg2"|`"`method'"'=="ivreg" {
    dis as error "To estimate IV regression models, specify method(ivregress)"
    exit 200
}
if `"`method'"'!="ivregress"&length(`"`indepexog'"')>0 {
    dis as error "indepexog argument can only be specified with method(ivregress)"
    exit 200
}
if `"`method'"'=="ivregress" {
    local ivr1 "("
    local ivr2 "=`iv')"
    local method ivregress 2sls
    if length(`"`iv'"')==0 {
        dis as error "Instrumental variable(s) must be included when specifying ivregress"
        dis as error "Specify the IVs using iv(varlist)"
        exit 200
    }    
}
else {
    local ivr1
    local ivr2
    local otherendog
}
if length(`"`onesided'"')!=0 {
    if `"`onesided'"'!="positive"&`"`onesided'"'!="negative" {
        local W1 "When specifying onesided(), only onesided(positive)"
        dis as error "`W1' or onesided(negative) are permissible"
        exit 200
    }
}

if length(`"`nulls'"')!=0 {
    local nnull : word count `nulls'
    local nvars : word count `varlist'
    if `nnull'!=`nvars' {
        local e1 "The number of values in the nulls() option is different"
        local e2 "When using the nulls() option,"
        dis as error "`e1' to the number of dependent variables indicated."
        dis as error "`e2' ensure that one null value is given for each hypothesis."
        exit 200
    }
        
    local j=1
    foreach null of numlist `nulls' {
        local beta0`j'=`null'
        local ++j
    }
}

local bopts
if length(`"`strata'"')!=0  local bopts `bopts' strata(`strata')
if length(`"`cluster'"')!=0 local bopts `bopts' cluster(`cluster')
if length(`"`verbose'"')==0 local q qui


*-------------------------------------------------------------------------------
*--- Run bootstrap reps to create null Studentized distribution
*-------------------------------------------------------------------------------
if length(`"`nobootstraps'"')==0 {
    local j=0
    local cand
    local wt [`weight' `exp']
    
    tempname nullvals
    tempfile nullfile
    file open `nullvals' using "`nullfile'", write all
    
    `q' dis "Displaying original (uncorrected) models:"
    foreach var of varlist `varlist' {
        local ++j
        local Xv `controls'
        if length(`"`bl'"')!=0 local Xv `controls' `var'`bl' 
        if length(`"`indepexog'"')==0 {
            `q' `method' `var' `ivr1'`indepvar' `otherendog'`ivr2' `Xv' `if' `in' `wt', `options'
        }
        else {
            `q' `method' `var' `ivr1'`otherendog'`ivr2' `indepvar' `Xv' `if' `in' `wt', `options'
        }
        if _rc!=0 {
            dis as error "Your original `method' does not work."
            dis as error "Please test the `method' and try again."
            exit _rc
        }
        local label`j' `: var label `var' '

        if length(`"`nulls'"')==0    local beta0`j'=0 
        if length(`"`onesided'"')==0 local t`j' = abs((_b[`indepvar']-`beta0`j'')/_se[`indepvar'])
        else                         local t`j' =     (_b[`indepvar']-`beta0`j'')/_se[`indepvar']
        local beta`j' = _b[`indepvar']
        matrix rtable = r(table)
        matrix pgrab  = rtable["pvalue","`indepvar'"] 
        local pv`var' = string(pgrab[1,1], "%6.4f")
        local pv`var's= pgrab[1,1]
        if length(`"`nulls'"')!=0 {
            qui test _b[`indepvar'] = `beta0`j''
            local pv`var' = string(r(p), "%6.4f")
            local pv`var's= r(p)
        }

        if `"`onesided'"'=="positive" {
            qui test `indepvar'=0
            local sgn = sign(_b[`indepvar'])
            if length(`"`r(F)'"')!=0 {
                local pv`var' = string(1-ttail(r(df_r),`sgn'*sqrt(r(F))), "%6.4f")
                local pv`var's=(1-ttail(r(df_r),`sgn'*sqrt(r(F))))
            }
            else {
                local pv`var's=normal(`sgn'*sqrt(r(chi2)))
            }
        }
        if `"`onesided'"'=="negative" {
            qui test `indepvar'=0
            local sgn = sign(_b[`indepvar'])
            if length(`"`r(F)'"')!=0 {
                local pv`var' = string(ttail(r(df_r),`sgn'*sqrt(r(F))), "%6.4f")
                local pv`var's= (ttail(r(df_r),`sgn'*sqrt(r(F))))
            }
            else {
                local pv`var's= 1-normal(`sgn'*sqrt(r(chi2)))

            }
        }
        
        local cand `cand' `j'    
        file write `nullvals' "b`j'; se`j';"
    }
    
    dis "Bootstrap replications (`reps'). This may take some time."
    if length(`"`dots'"')==0 {
        dis "----+--- 1 ---+--- 2 ---+--- 3 ---+--- 4 ---+--- 5"
    }
    forvalues i=1/`reps' {
        local j=0
        preserve
        bsample `if' `in', `bopts'
        if length(`"`dots'"')==0 {
            display in smcl "." _continue
            if mod(`i',50)==0 dis "     `i'"
        }
        foreach var of varlist `varlist' {
            local ++j
            local Xv `controls'
            if length(`"`bl'"')!=0 local Xv `controls' `var'`bl' 
            if length(`"`indepexog'"')==0 {
                qui `method' `var' `ivr1'`indepvar'  `otherendog'`ivr2' `Xv' `if' `in' `wt', `options'
            }
            else {
                qui `method' `var' `ivr1'`otherendog'`ivr2' `indepvar' `Xv' `if' `in' `wt', `options'
            }
            if `j'==1 file write `nullvals' _n "`= _b[`indepvar']';`= _se[`indepvar']'"
            else file write `nullvals' ";`= _b[`indepvar']';`= _se[`indepvar']'"
        }
        restore
    }
    
    preserve
    file close `nullvals'
    qui insheet using `nullfile', delim(";") names clear
}
else {
    preserve
    local cand
    local j=0
    tokenize `varlist' 
    foreach beta of numlist `pointestimates' {
        local ++j
        qui count if ``j''!=.
        local reps=r(N)
        
        gen b`j'=``j''
        qui sum b`j'
        local beta`j' = `beta' 
        local cand `cand' `j'
        local label`j' `: var label ``j'' '
        
        local pv``j''s=.
    }
    local j=0
    tokenize `stdests'
    foreach se of numlist `stderrs' {
        local ++j
        gen se`j'=``j''
        if length(`"`nulls'"')==0    local beta0`j'=0 
        
        local se`j' = `se'
        if length(`"`onesided'"')==0 local t`j' = abs((`beta`j''-`beta0`j'')/`se`j'')
        else                         local t`j' =     (`beta`j''-`beta0`j'')/`se`j''

        if length(`"`nullimposed'"')!=0 local beta`j'=0
    }
}

matrix pvalues = J(`j',3,.)
if length(`"`holm'"')!=0 matrix pvalues = J(`j',4,.)
*-------------------------------------------------------------------------------
*--- Create null t-distribution
*-------------------------------------------------------------------------------
foreach num of numlist 1(1)`j' {    
    qui sum     b`num'
    qui gen     t`num'=(b`num'-`beta`num'')/se`num'
    qui replace b`num'=abs((b`num'-`beta`num'')/se`num')
}


*-------------------------------------------------------------------------------
*--- Create stepdown value in descending order based on t-stats
*-------------------------------------------------------------------------------
local maxt = -1000000000
local pval = 0
local rank
local Holm = `j'

tokenize `varlist'
local ii=0
while length("`cand'")!=0 {
    local ++ii
    local donor_tvals

    if length(`"`onesided'"')==0|`"`onesided'"'=="negative" {
        foreach var of local cand {
            if `t`var''>`maxt' {
                local maxt = `t`var''
                local maxv `var'
                if length(`"`onesided'"')==0  local ovar  b`var'
                if `"`onesided'"'=="negative" local ovar  t`var'
            }
            *dis "Maximum t among remaining candidates is `maxt' (variable `maxv')"
            if length(`"`onesided'"')==0  local donor_tvals `donor_tvals' b`var'
            if `"`onesided'"'=="negative" local donor_tvals `donor_tvals' t`var'
        }
        qui egen empiricalDist = rowmax(`donor_tvals')    
        qui count if empiricalDist>=`maxt'  & empiricalDist != .
        local cnum = r(N)
        if length(`"`plusone'"')!=0 local pval = (`cnum')/(`reps')
        else if length(`"`plusone'"')==0 local pval = (`cnum'+1)/(`reps'+1)

        qui count if `ovar'>=`maxt' & `maxt'!=.
        local cnum = r(N)
        if length(`"`plusone'"')!=0 local pvalBS = `cnum'/`reps'
        else if length(`"`plusone'"')==0 local pvalBS = (`cnum'+1)/(`reps'+1)
        
        local pbs`maxv's= `pvalBS'
        local prm`maxv's= `pval'
        local prh`maxv's= min(`pvalBS'*`Holm',1)
        if length(`"`prmsm1'"')!=0 local prm`maxv's=max(`prm`maxv's',`prmsm1')
        local prm`maxv' = string(`prm`maxv's',"%6.4f")
        local pbs`maxv' = string(`pvalBS',"%6.4f")
        local prmsm1 = `prm`maxv's'
        if length(`"`graph'"')!=0 {
            gen tDist`ii'=empiricalDist
            local tt`ii' = `t`maxv''
            local ll`ii' "`label`maxv''"
            local yy`ii' ``maxv''
            local pp`ii' `prm`maxv''
        }
    }
    else {
        local mint = .
        foreach var of local cand {
            if `t`var''<`mint' {
                local mint = `t`var''
                local minv `var'
                local ovar t`var'
            }
            *dis "Minimum t among remaining candidates is `mint' (variable `minv')"
            local donor_tvals `donor_tvals' t`var'
        }
        qui egen empiricalDist = rowmin(`donor_tvals')
        qui count if empiricalDist <= `mint' & empiricalDist != .
        local cnum = r(N)
        if length(`"`plusone'"')!=0  local pval = (`cnum')/(`reps')
        else  local pval = (`cnum'+1)/(`reps'+1)
        qui count if `ovar'<=`mint' & `mint'!=.
        local cnum = r(N)
        if length(`"`plusone'"')!=0  local pvalBS = (`cnum')/(`reps')
        else local pvalBS = (`cnum'+1)/(`reps'+1)
        
        local prm`minv's= `pval'
        if length(`"`prmsm1'"')!=0 local prm`minv's=max(`prm`minv's',`prmsm1')
        local prm`minv' = string(`prm`minv's',"%6.4f")
        local prmsm1 = `prm`minv's'
        if length(`"`graph'"')!= 0 {
            gen tDist`ii'=empiricalDist
            local tt`ii' = `t`minv''
            local ll`ii' "`label`minv''"
            local yy`ii' ``minv''
            local pp`ii' `prm`minv''
        }
    }
    drop empiricalDist 
    local rank `rank' `maxv' `minv'
    local candnew
    foreach c of local cand {
        local match = 0
        foreach r of local rank {
            if `r'==`c' local match = 1
        }
        if `match'==0 local candnew `candnew' `c'
    }
    local cand `candnew'
    local maxt = -1000000000
    local maxv = 0
    local --Holm
}

if length(`"`graph'"')!= 0 {
    if length(`"`onesided'"')==0 {
        foreach num of numlist 1(1)`ii' {
            local title "Variable `yy`num''"
            if length(`"`varlabels'"')!=0 local title "`ll`num''"
            
            #delimit ;
            twoway hist tDist`num', bcolor(gs12) xline(`tt`num'', lcolor(red)) ||
             function y=sqrt(2)/sqrt(c(pi))*exp(-x^2/2), range(0 6)
             name(g`num', replace) scheme(sj) nodraw legend(off)
             title(`title') note("p-value = `pp`num''");
            #delimit cr
            local graphs `graphs' g`num'
        }
    }
    else {
        foreach num of numlist 1(1)`ii' {
            local title "Variable `yy`num''" 
            if length(`"`varlabels'"')!=0 local title "`ll`num''"
            #delimit ;
            twoway hist tDist`num', bcolor(gs12) xline(`tt`num'', lcolor(red)) ||
             function y=1/sqrt(2*c(pi))*exp(-x^2/2), range(-4 4)
             name(g`num', replace) scheme(sj) nodraw legend(off)
             title(`title') note("p-value = `pp`num''");
            #delimit cr
            local graphs `graphs' g`num'
        }
    }
    graph combine `graphs', scheme(sj)
}

restore

*-------------------------------------------------------------------------------
*--- Report and export p-values
*-------------------------------------------------------------------------------
local vardisplay
local linelength=0
foreach var of varlist `varlist' {
    local linelength=`linelength'+length("`var'")
    if `linelength'>57 {
        local vardisplay "`vardisplay'" _newline _col(22) "`var'"
        local linelength=length("`var'")
    }
    else local vardisplay "`vardisplay' `var'"
}
local j=0
dis _newline
dis _newline
dis "Romano-Wolf step-down adjusted p-values"
dis _newline
if length(`"`nobootstraps'"')==0 dis "Dependent variable:  `indepvar'"
dis "Outcome variables:  `vardisplay'"
dis "Number of resamples: `reps'"
dis _newline
dis "{hline 78}"
dis "Outcome Variable    | Model p-value    Resample p-value    Romano-Wolf p-value"
dis "{hline 20}+{hline 57}"
foreach var of varlist `varlist' {
    local ++j
    display as text %19s abbrev("`var'",19) " {c |}    " /*
        */  as result %6.4f `pv`var's' "             "   /*
        */  as result %6.4f `pbs`j's' "              "   /*
        */  as result %6.4f `prm`j's'
    ereturn scalar rw_`var'=`prm`j's'
    matrix pvalues[`j',1]=`pv`var's'
    matrix pvalues[`j',2]=`pbs`j's'
    matrix pvalues[`j',3]=`prm`j's'
    if length(`"`holm'"')!=0 matrix pvalues[`j',4]=`prh`j's'
}
dis "{hline 78}"
ereturn matrix pvalues=pvalues
end
