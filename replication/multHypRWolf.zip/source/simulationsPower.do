clear all

global OUT "/home/damian/investigacion/2019/multHypRWolf/results"
global LOG "/home/damian/investigacion/2019/multHypRWolf/log"

cap log close
log using "$LOG/simulationsPower.txt", text replace

set seed 12011303
local I=1000
local B=200

set obs 34
gen beta  = (_n/100)*3-0.02
gen probNA = .
gen probRW = .
gen probHO = .
local k = 1
foreach beta of numlist 0.01(0.03)1 {
    dis "\beta is: `beta'"
    local propNA = 0
    local propHO = 0
    local propRW = 0
    
    preserve
    forval i=1/`I' {
        dis "SIM NUMBER `i'"
        clear all
        set obs 100
        gen treat  = runiform()>0.5
        foreach num of numlist 1(1)10 {
            gen c`num'     = rnormal()
        }
        local r=0.5
        #delimit ;
        mat corr = (1,`r',`r',`r',`r',`r',`r',`r',`r',`r' \
                    `r',1,`r',`r',`r',`r',`r',`r',`r',`r' \
                    `r',`r',1,`r',`r',`r',`r',`r',`r',`r' \         
                    `r',`r',`r',1,`r',`r',`r',`r',`r',`r' \
                    `r',`r',`r',`r',1,`r',`r',`r',`r',`r' \
                    `r',`r',`r',`r',`r',1,`r',`r',`r',`r' \
                    `r',`r',`r',`r',`r',`r',1,`r',`r',`r' \
                    `r',`r',`r',`r',`r',`r',`r',1,`r',`r' \
                    `r',`r',`r',`r',`r',`r',`r',`r',1,`r' \
                    `r',`r',`r',`r',`r',`r',`r',`r',`r',1);
        #delimit cr
        mat corsim = cholesky(corr)
        
        
        foreach num of numlist 1(1)10 {
            matrix eps`num' = corsim[`num',1..10]
            matrix score epsilon`num' = eps`num'
            gen y`num'  = 1 + `beta'*treat   + epsilon`num'
        }
        rwolf y1 y2 y3 y4 y5 y6 y7 y8 y9 y10, indepvar(treat) reps(`B') holm        
        matrix pvals = e(pvalues)
        foreach num of numlist 1(1)10 {
            local pna = pvals[`num',2]
            local prw = pvals[`num',3]
            local pho = pvals[`num',4]            
            
            if `pna'<=0.05 local ++propNA
            if `prw'<=0.05 local ++propRW
            if `pho'<=0.05 local ++propHO
        }
    }
    restore
    dis "when beta is `beta', proportion Naive rejected is `=`propNA'/1000'"
    dis "when beta is `beta', proportion Holm rejected is `=`propHO'/1000'"
    dis "when beta is `beta', proportion R-W rejected is `=`propRW'/1000'"

    replace probNA = `propNA'/(`I'*10) in `k'
    replace probHO = `propHO'/(`I'*10) in `k'
    replace probRW = `propRW'/(`I'*10) in `k'
    sum prob*
    local ++k
}
#delimit ;
twoway connected probNA beta 
   ||  connected probHO beta
   ||  connected probRW beta, scheme(sj)
ytitle("Proportion of Nulls Correctly Rejected")
xtitle("Value for {&beta}")
legend(lab(1 "Uncorrected") lab(2 "Holm") lab(3 "Romano-Wolf") rows(1));
graph export "$OUT/powerExample.eps", replace;
#delimit cr

save "$OUT/simulationResults.dta", replace

log close

