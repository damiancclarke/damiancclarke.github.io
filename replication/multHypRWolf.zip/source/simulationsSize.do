global OUT "/home/damian/investigacion/2019/multHypRWolf/results"
global LOG "/home/damian/investigacion/2019/multHypRWolf/log"

cap log close
log using "$LOG/simulationsSize.txt", text replace

set seed 12011303
local I=5000
local B=500

foreach c of numlist 0 25 50 75 {
    foreach p in A B C {
        foreach s in 5 10 {
            local FWER_RW_`c'_`s'_`p'  = 0
            local FWER_Ho_`c'_`s'_`p'  = 0
            local FWER_Na_`c'_`s'_`p'  = 0
            
            local NumR_RW_`c'_`s'_`p'  = 0
            local NumR_Ho_`c'_`s'_`p'  = 0
            local NumR_Na_`c'_`s'_`p'  = 0
        }
    }

    if `c'==0 {
    forval i=1/`I' {
        dis "SIM NUMBER `i', rho=`c'"
        clear all
        set obs 100
        gen treat  = runiform()>0.5
        foreach num of numlist 1(1)10 {
            gen c`num'     = rnormal()
        }
        local r=`c'/100
        #delimit ;
        mat corr = (1,`r',`r',`r',`r',`r',`r',`r',`r',`r' \
                    `r',1,`r',`r',`r',`r',`r',`r',`r',`r' \
                    `r',`r',1,`r',`r',`r',`r',`r',`r',`r' \
                    `r',`r',`r',1,`r',`r',`r',`r',`r',`r' \
                    `r',`r',`r',`r',1,`r',`r',`r',`r',`r' \
                    `r',`r',`r',`r',`r',1,`r',`r',`r',`r' \
                    `r',`r',`r',`r',`r',`r',1,`r',`r',`r' \
                    `r',`r',`r',`r',`r',`r',`r',1,`r',`r' \
                    `r',`r',`r',`r',`r',`r',`r',`r',1,`r' \
                    `r',`r',`r',`r',`r',`r',`r',`r',`r',1 );
        #delimit cr
        mat corsim = cholesky(corr)
    
        foreach num of numlist 1(1)10 {
            matrix eps`num' = corsim[`num',1..10]
            matrix score epsilon`num' = eps`num'
            gen y`num'  = 1 + 0*treat   + epsilon`num'
            gen yr`num' = 1 + 0.5*treat + epsilon`num'
        }
        
        *----------------------------------------------------------------------
        *--- PANEL A
        *----------------------------------------------------------------------
        if `i'==1 {
            rwolf y1 y2 y3 y4 y5 y6 y7 y8 y9 y10, indepvar(treat) reps(`B') holm graph
            graph export "$OUT/simula2.eps", replace
        }
        else {
            rwolf y1 y2 y3 y4 y5 y6 y7 y8 y9 y10, indepvar(treat) reps(`B') holm nodots
        }
        matrix pvals = e(pvalues)

        foreach n of numlist 5 10 {
            local anyNa`n' = 0 
            local anyRw`n' = 0
            local anyHo`n' = 0
        }
        
        foreach num of numlist 1(1)10 {
            local pna = pvals[`num',2]
            local prw = pvals[`num',3]
            local pho = pvals[`num',4]            
            foreach n of numlist 5 10 {
                local level = `n'/100
                if `pna'<=`level' local ++anyNa`n'
                if `prw'<=`level' local ++anyRw`n'
                if `pho'<=`level' local ++anyHo`n'
            }
        }

        foreach n of numlist 5 10 {
            if `anyNa`n''>0 local ++FWER_Na_`c'_`n'_A
            if `anyRw`n''>0 local ++FWER_RW_`c'_`n'_A
            if `anyHo`n''>0 local ++FWER_Ho_`c'_`n'_A

            dis "Panel A"
            dis "Currently `FWER_Na_`c'_`n'_A' Naive rejected of `i' at level `n'"
            dis "Currently `FWER_RW_`c'_`n'_A' R-W   rejected of `i' at level `n'"
            dis "Currently `FWER_Ho_`c'_`n'_A' Holm  rejected of `i' at level `n'"
        }
        

        *----------------------------------------------------------------------
        *--- PANEL B
        *----------------------------------------------------------------------
        rwolf y1 y2 y3 y4 y5 yr6 yr7 yr8 yr9 yr10, indepvar(treat) reps(`B') holm nodots
        matrix pvals = e(pvalues)

        foreach n of numlist 5 10 {
            local anyNa`n' = 0 
            local anyRw`n' = 0
            local anyHo`n' = 0
        }
        
        foreach num of numlist 1(1)5 {
            local pna = pvals[`num',2]
            local prw = pvals[`num',3]
            local pho = pvals[`num',4]            
            foreach n of numlist 5 10 {
                local level = `n'/100
                if `pna'<=`level' local ++anyNa`n'
                if `prw'<=`level' local ++anyRw`n'
                if `pho'<=`level' local ++anyHo`n'
            }
        }
        foreach num of numlist 6(1)10 {
            local pna = pvals[`num',2]
            local prw = pvals[`num',3]
            local pho = pvals[`num',4]            
            foreach n of numlist 5 10 {
                local level = `n'/100
                if `pna'<=`level' local ++NumR_Na_`c'_`n'_B
                if `prw'<=`level' local ++NumR_RW_`c'_`n'_B
                if `pho'<=`level' local ++NumR_Ho_`c'_`n'_B
            }
        }

        foreach n of numlist 5 10 {
            if `anyNa`n''>0 local ++FWER_Na_`c'_`n'_B
            if `anyRw`n''>0 local ++FWER_RW_`c'_`n'_B
            if `anyHo`n''>0 local ++FWER_Ho_`c'_`n'_B

            dis "Panel B"
            dis "Currently `FWER_Na_`c'_`n'_B' Naive rejected of `i' at level `n'"
            dis "Currently `FWER_RW_`c'_`n'_B' R-W   rejected of `i' at level `n'"
            dis "Currently `FWER_Ho_`c'_`n'_B' Holm  rejected of `i' at level `n'"

            dis "`NumR_Na_`c'_`n'_B' Naive correctly rejected of `i' at level `n'"
            dis "`NumR_RW_`c'_`n'_B' R-W   correctly rejected of `i' at level `n'"
            dis "`NumR_Ho_`c'_`n'_B' Holm  correctly rejected of `i' at level `n'"
        }

        *----------------------------------------------------------------------
        *--- PANEL C
        *----------------------------------------------------------------------
        rwolf yr1 yr2 yr3 yr4 yr5 yr6 yr7 yr8 yr9 yr10, indepvar(treat) reps(`B') holm nodots
        matrix pvals = e(pvalues)

        foreach num of numlist 1(1)10 {
            local pna = pvals[`num',2]
            local prw = pvals[`num',3]
            local pho = pvals[`num',4]
            foreach n of numlist 5 10 {
                local level = `n'/100
                if `pna'<=`level' local ++NumR_Na_`c'_`n'_C
                if `prw'<=`level' local ++NumR_RW_`c'_`n'_C
                if `pho'<=`level' local ++NumR_Ho_`c'_`n'_C
            }
        }

        foreach n of numlist 5 10 {
            dis "Panel C"
            dis "`NumR_Na_`c'_`n'_C' Naive correctly rejected of `i' at level `n'"
            dis "`NumR_RW_`c'_`n'_C' R-W   correctly rejected of `i' at level `n'"
            dis "`NumR_Ho_`c'_`n'_C' Holm  correctly rejected of `i' at level `n'"
        }        
    }
    }
}

*-------------------------------------------------------------------------------
*--- (2A) Write Table - Panel A
*-------------------------------------------------------------------------------
file open results using "$OUT/sizeSims2-A1.tex", write replace

#delimit ;
file write results "FWER Uncorrected &"
 (string(`FWER_Na_0_5_A'/`I',"%05.3f"))  "&"  (string(`FWER_Na_0_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Na_25_5_A'/`I',"%05.3f")) "&" (string(`FWER_Na_25_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Na_50_5_A'/`I',"%05.3f")) "&" (string(`FWER_Na_50_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Na_75_5_A'/`I',"%05.3f")) "&" (string(`FWER_Na_75_10_A'/`I',"%05.3f")) "\\" _n ;
file write results "FWER Holm &"
 (string(`FWER_Ho_0_5_A'/`I',"%05.3f"))  "&"  (string(`FWER_Ho_0_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_25_5_A'/`I',"%05.3f")) "&" (string(`FWER_Ho_25_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_50_5_A'/`I',"%05.3f")) "&" (string(`FWER_Ho_50_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_75_5_A'/`I',"%05.3f")) "&" (string(`FWER_Ho_75_10_A'/`I',"%05.3f")) "\\" _n ;
file write results "FWER Romano-Wolf &"
 (string(`FWER_RW_0_5_A'/`I',"%05.3f"))  "&"  (string(`FWER_RW_0_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_RW_25_5_A'/`I',"%05.3f")) "&" (string(`FWER_RW_25_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_RW_50_5_A'/`I',"%05.3f")) "&" (string(`FWER_RW_50_10_A'/`I',"%05.3f")) "&"
 (string(`FWER_RW_75_5_A'/`I',"%05.3f")) "&" (string(`FWER_RW_75_10_A'/`I',"%05.3f")) "\\" _n ;
#delimit cr
file close results


*-------------------------------------------------------------------------------
*--- (2B) Write Table - Panel B
*-------------------------------------------------------------------------------
local d=`I'*5

file open results using "$OUT/sizeSims2-B1.tex", write replace
#delimit ;
file write results "FWER Uncorrected &"
 (string(`FWER_Na_0_5_B'/`I',"%05.3f"))  "&"  (string(`FWER_Na_0_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Na_25_5_B'/`I',"%05.3f")) "&" (string(`FWER_Na_25_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Na_50_5_B'/`I',"%05.3f")) "&" (string(`FWER_Na_50_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Na_75_5_B'/`I',"%05.3f")) "&" (string(`FWER_Na_75_10_B'/`I',"%05.3f")) "\\" _n ;
file write results "FWER Holm &"
 (string(`FWER_Ho_0_5_B'/`I',"%05.3f"))  "&"  (string(`FWER_Ho_0_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_25_5_B'/`I',"%05.3f")) "&" (string(`FWER_Ho_25_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_50_5_B'/`I',"%05.3f")) "&" (string(`FWER_Ho_50_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_Ho_75_5_B'/`I',"%05.3f")) "&" (string(`FWER_Ho_75_10_B'/`I',"%05.3f")) "\\" _n ;
file write results "FWER Romano-Wolf &"
 (string(`FWER_RW_0_5_B'/`I',"%05.3f"))  "&"  (string(`FWER_RW_0_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_RW_25_5_B'/`I',"%05.3f")) "&" (string(`FWER_RW_25_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_RW_50_5_B'/`I',"%05.3f")) "&" (string(`FWER_RW_50_10_B'/`I',"%05.3f")) "&"
 (string(`FWER_RW_75_5_B'/`I',"%05.3f")) "&" (string(`FWER_RW_75_10_B'/`I',"%05.3f")) "\\" _n ;
file write results "Rejected Uncorrected &"
 (string(`NumR_Na_0_5_B'/`d',"%05.3f"))  "&"  (string(`NumR_Na_0_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Na_25_5_B'/`d',"%05.3f")) "&" (string(`NumR_Na_25_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Na_50_5_B'/`d',"%05.3f")) "&" (string(`NumR_Na_50_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Na_75_5_B'/`d',"%05.3f")) "&" (string(`NumR_Na_75_10_B'/`d',"%05.3f")) "\\" _n ;
file write results "Rejected Holm &"
 (string(`NumR_Ho_0_5_B'/`d',"%05.3f"))  "&"  (string(`NumR_Ho_0_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_25_5_B'/`d',"%05.3f")) "&" (string(`NumR_Ho_25_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_50_5_B'/`d',"%05.3f")) "&" (string(`NumR_Ho_50_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_75_5_B'/`d',"%05.3f")) "&" (string(`NumR_Ho_75_10_B'/`d',"%05.3f")) "\\" _n ;
file write results "Rejected R-W &"
 (string(`NumR_RW_0_5_B'/`d',"%05.3f"))  "&"  (string(`NumR_RW_0_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_RW_25_5_B'/`d',"%05.3f")) "&" (string(`NumR_RW_25_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_RW_50_5_B'/`d',"%05.3f")) "&" (string(`NumR_RW_50_10_B'/`d',"%05.3f")) "&"
 (string(`NumR_RW_75_5_B'/`d',"%05.3f")) "&" (string(`NumR_RW_75_10_B'/`d',"%05.3f")) "\\" _n ;
#delimit cr
file close results


*-------------------------------------------------------------------------------
*--- (2C) Write Table - Panel C
*-------------------------------------------------------------------------------
local d=`I'*10

file open results using "$OUT/sizeSims2-C1.tex", write replace
#delimit ;
file write results "Rejected Uncorrected &"
 (string(`NumR_Na_0_5_C'/`d',"%05.3f"))  "&"  (string(`NumR_Na_0_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Na_25_5_C'/`d',"%05.3f")) "&" (string(`NumR_Na_25_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Na_50_5_C'/`d',"%05.3f")) "&" (string(`NumR_Na_50_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Na_75_5_C'/`d',"%05.3f")) "&" (string(`NumR_Na_75_10_C'/`d',"%05.3f")) "\\" _n ;
file write results "Rejected Holm &"
 (string(`NumR_Ho_0_5_C'/`d',"%05.3f"))  "&"  (string(`NumR_Ho_0_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_25_5_C'/`d',"%05.3f")) "&" (string(`NumR_Ho_25_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_50_5_C'/`d',"%05.3f")) "&" (string(`NumR_Ho_50_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_Ho_75_5_C'/`d',"%05.3f")) "&" (string(`NumR_Ho_75_10_C'/`d',"%05.3f")) "\\" _n ;
file write results "Rejected R-W &"
 (string(`NumR_RW_0_5_C'/`d',"%05.3f"))  "&"  (string(`NumR_RW_0_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_RW_25_5_C'/`d',"%05.3f")) "&" (string(`NumR_RW_25_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_RW_50_5_C'/`d',"%05.3f")) "&" (string(`NumR_RW_50_10_C'/`d',"%05.3f")) "&"
 (string(`NumR_RW_75_5_C'/`d',"%05.3f")) "&" (string(`NumR_RW_75_10_C'/`d',"%05.3f")) "\\" _n ;
#delimit cr
file close results


log close

