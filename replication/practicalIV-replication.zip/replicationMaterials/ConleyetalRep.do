sjlog using "./excerpts/Conleyetal", replace
use Conleyetal2012, clear
local xvar i2 i3 i4 i5 i6 i7 age age2 fsize hs smcol col marr twoearn db pira hown
plausexog ltz net_tfa `xvar' (p401 = e401), omega(25000) mu(0) level(.99) vce(robust) graph(p401) graphmu(0 1000 2000 3000 4000 5000) graphomega(0 333333.33 1333333.3 3000000 5333333.3 8333333.3) graphdelta(0 2000 4000 6000 8000 10000)
sjlog close, replace
