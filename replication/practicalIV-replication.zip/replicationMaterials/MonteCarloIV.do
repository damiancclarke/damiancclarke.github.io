/* MonteCarloIV.do                                         yyyy-mm-dd:2017-05-21
----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8

This script runs Monte Carlo simulations for IV bounds using Conley et al (2012)
and Nevo and Rosen (2012) bounding procedures. The Monte Carlo procedure is desc
ribed in "Practical Considerations for Questionable IVs" (Clarke and Matta).

This script can be replicated by simply changing the FIG, TAB and LOG globals de
fined on lines 21-22, which exports tabular results for inclusion in a LaTeX tab
le and a log file.
*/

vers 11
clear all
set more off
cap log close

*-------------------------------------------------------------------------------
*-- (1) Globals, settings
*-------------------------------------------------------------------------------
global TAB "./tables"
global FIG "./figures"
global LOG "./excerpts"

log using "$LOG/MonteCarloIV.txt", text replace

set seed     12012017
local N      = 1000
scalar Beta  = 3
set obs      `N'

*-------------------------------------------------------------------------------
*-- (2a) Simulate following description in paper for low correlation between x,u
*-------------------------------------------------------------------------------
file open simulations using "$TAB/SimulationsA.tex", write replace
foreach var in u z v w {
    gen `var' = rnormal()
}

gen x  = 0.4*u  + -0.6*z + v
gen y1 = Beta*x + 0.1*z + u
gen y2 = Beta*x + 0.2*z + u
gen y3 = Beta*x + 0.3*z + u
gen y4 = Beta*x + 0.4*z + u

gen u1=0.1*z + u
gen u2=0.2*z + u
gen u3=0.3*z + u
gen u4=0.4*z + u

corr x u4
corr z u4

*-------------------------------------------------------------------------------
*-- (2b) Estimate bounds using Conley et al and Nevo and Rosen
*-------------------------------------------------------------------------------
foreach s of numlist 1 2 3 4 {
    local max = 0.2*`s'
    local mean = `s'/10
    local vari = `s'/100

    plausexog uci y`s' (x=z), gmin(0) gmax(`max')
    local lb`s'A = string(e(lb_x),"%5.3f")
    local ub`s'A = string(e(ub_x),"%5.3f")

    plausexog ltz y`s' (x=z), mu(`mean') omega(`vari')
    local lb`s'B = string(e(lb_x),"%5.3f")
    local ub`s'B = string(e(ub_x),"%5.3f")
    corr x u`s'
    local c=string(r(rho), "%04.2f")
    corr z u`s'
    local d=string(r(rho), "%04.2f")

    file write simulations "0.`s'&`c'&`d'&&[`lb`s'A'&`ub`s'A']&[`lb`s'B'&`ub`s'B']"
	
    imperfectiv y`s' (x=z), noassumption4
    local lb`s'C= string(e(CIlb_x),"%5.3f")
    local ub`s'C = string(e(CIub_x),"%5.3f")
    
    imperfectiv y`s' (x=z)
    local lb`s'D= string(e(CIlb_x),"%5.3f")
    local ub`s'D = string(e(CIub_x),"%5.3f")
	
    file write simulations "&[`lb`s'C'&`ub`s'C']&[`lb`s'D'&`ub`s'D'] \\"_n
}
file close simulations

*-------------------------------------------------------------------------------
*-- (3a) Simulate following description in paper for med correlation between x,u
*-------------------------------------------------------------------------------
drop x y1 y2 y3 y4 u1-u4
file open simulations using "$TAB/SimulationsB.tex", write replace

gen x  = 1*u  + -0.6*z + v
gen y1 = Beta*x + 0.1*z + u
gen y2 = Beta*x + 0.2*z + u
gen y3 = Beta*x + 0.3*z + u
gen y4 = Beta*x + 0.4*z + u
gen u1=0.1*z + u
gen u2=0.2*z + u
gen u3=0.3*z + u
gen u4=0.4*z + u

*-------------------------------------------------------------------------------
*-- (3b) Estimate bounds using Conley et al and Nevo and Rosen
*-------------------------------------------------------------------------------
foreach s of numlist 1 2 3 4 {
    local max = 0.2*`s'
    local mean = `s'/10
    local vari = `s'/100

    plausexog uci y`s' (x=z), gmin(0) gmax(`max')
    local lb`s'A = string(e(lb_x),"%5.3f")
    local ub`s'A = string(e(ub_x),"%5.3f")

    plausexog ltz y`s' (x=z), mu(`mean') omega(`vari')
    local lb`s'B = string(e(lb_x),"%5.3f")
    local ub`s'B = string(e(ub_x),"%5.3f")
    corr x u`s'
    local c=string(r(rho), "%04.2f")
    corr z u`s'
    local d=string(r(rho), "%04.2f")

    file write simulations "0.`s'&`c'&`d'&&[`lb`s'A'&`ub`s'A']&[`lb`s'B'&`ub`s'B']"

    imperfectiv y`s' (x=z), noassumption4
    local lb`s'C= string(e(CIlb_x),"%5.3f")
    local ub`s'C = string(e(CIub_x),"%5.3f")
	
    imperfectiv y`s' (x=z)
    local lb`s'D= string(e(CIlb_x),"%5.3f")
    local ub`s'D = string(e(CIub_x),"%5.3f")
	
    file write simulations "&[`lb`s'C'&`ub`s'C']&[`lb`s'D'&`ub`s'D'] \\"_n
}
file close simulations

*-------------------------------------------------------------------------------
*-- (4a) Simulate following description in paper for med correlation between x,u
*-------------------------------------------------------------------------------
drop x y1 y2 y3 y4 u1-u4
file open simulations using "$TAB/SimulationsC.tex", write replace

gen x  = 3*u  + -0.6*z + v
gen y1 = Beta*x + 0.1*z + u
gen y2 = Beta*x + 0.2*z + u
gen y3 = Beta*x + 0.3*z + u
gen y4 = Beta*x + 0.4*z + u
gen u1=0.1*z + u
gen u2=0.2*z + u
gen u3=0.3*z + u
gen u4=0.4*z + u

*-------------------------------------------------------------------------------
*-- (4b) Estimate bounds using Conley et al and Nevo and Rosen
*-------------------------------------------------------------------------------
foreach s of numlist 1 2 3 4 {
    local max = 0.2*`s'
    local mean = `s'/10
    local vari = `s'/100

    plausexog uci y`s' (x=z), gmin(0) gmax(`max')
    local lb`s'A = string(e(lb_x),"%5.3f")
    local ub`s'A = string(e(ub_x),"%5.3f")

    plausexog ltz y`s' (x=z), mu(`mean') omega(`vari')
    local lb`s'B = string(e(lb_x),"%5.3f")
    local ub`s'B = string(e(ub_x),"%5.3f")
    corr x u`s'
    local c=string(r(rho), "%04.2f")
    corr z u`s'
    local d=string(r(rho), "%04.2f")

    file write simulations "0.`s'&`c'&`d'&&[`lb`s'A'&`ub`s'A']&[`lb`s'B'&`ub`s'B']"
    
    imperfectiv y`s' (x=z), noassumption4
    local lb`s'C= string(e(CIlb_x),"%5.3f")
    local ub`s'C = string(e(CIub_x),"%5.3f")
	
    imperfectiv y`s' (x=z)
    local lb`s'D= string(e(CIlb_x),"%5.3f")
    local ub`s'D = string(e(CIub_x),"%5.3f")
	
    file write simulations "&[`lb`s'C'&`ub`s'C']&[`lb`s'D'&`ub`s'D'] \\"_n
}
file close simulations


*-------------------------------------------------------------------------------
*-- (5) Graphs as figures 1a-b in the paper
*-------------------------------------------------------------------------------
drop x y3
sjlog using "$LOG/simulations3", replace
gen x  = 0.33*u  + 0.6*z + v
gen y3 = Beta*x + 0.3*z + u

#delimit ;
quietly plausexog ltz y3 (x=z), omega(0.01) mu(0.3) graph(x)
graphomega(0 0.0225 0.09 0.2025 0.36 0.5625) graphmu(0 0.15 0.3 0.45 0.6 0.75)
graphdelta(0 0.15 0.3 0.45 0.6 0.75) scheme(sj)
ytitle(Estimated {&beta}) xtitle({&delta})
xlabel(0 "0" 0.2 "0.20" 0.4 "0.40" 0.6 "0.60" 0.8 "0.80")
legend(order(1 "Point Estimate (LTZ)" 2 "CI (LTZ)")) ylabel(0(1)5);
sjlog close, replace;
graph export "$FIG/plausTest2.eps", replace;
#delimit cr

gen boundNl=.
gen boundNu=.
gen boundUl=.
gen boundUu=.
gen value  =.
local jj=1
foreach num of numlist 0 0.15 0.3 0.45 0.6 0.75 {
    local v=`num'^2
    local u=2*`num'
    plausexog ltz y3 (x=z), mu(`num') omega(`v')
    replace boundNl=e(lb_x) in `jj'
    replace boundNu=e(ub_x) in `jj'
    plausexog ltz y3 (x=z), dist(uniform, 0 `u')
    replace boundUl=e(lb_x) in `jj'
    replace boundUu=e(ub_x) in `jj'
    replace value=`num' in `jj'
    local ++jj
}
#delimit ;
twoway line boundNl value, lpattern(solid)
   ||  line boundNu value, lpattern(solid)
   ||  line boundUl value, lpattern(dash)
   ||  line boundUu value, lpattern(dash) scheme(sj)
ytitle(Estimated {&beta}) xtitle({&delta})
xlabel(0 "0" 0.2 "0.20" 0.4 "0.40" 0.6 "0.60" 0.8 "0.80")
legend(order(1 "Bounds with Normal Prior" 3 "Bounds with Uniform Prior"))
ylabel(0(1)5);
graph export "$FIG/plausTest-NormUniform.eps", replace;
#delimit cr


*-------------------------------------------------------------------------------
*-- (6) Appendix 2
*-------------------------------------------------------------------------------
clear
sjlog using "$LOG/simulations4", replace

set obs 1000
foreach var in u z1 z2 v w {
    gen `var'=rnormal()
}
gen x  = -0.6*z1 - 0.40*z2 + 0.33*u  + v
gen y1 =  3.0*x  + 0.10*z1 + 0.20*z2 + u

plausexog uci y1 (x = z1 z2), gmin(0 0) gmax(0.2 0.4)
plausexog ltz y1 (x = z1 z2), mu(0.1 0.2) omega(0.01 0.02)

imperfectiv y1 (x=z1 z2), noassumption4
imperfectiv y1 (x=z1 z2)


sjlog close, replace

