clear
sjlog using "excerpts/simulations1", replace
set obs 1000
set seed 1716
foreach var in u z v w {
    gen `var' = rnormal()
}
gen x  = -0.6*z + 0.33*u + v
gen y1 =  3.0*x + 0.10*z + u

plausexog uci y1 (x=z), gmin(0) gmax(0.2)
plausexog ltz y1 (x=z), mu(0.1) omega(0.01)
sjlog close, replace
sjlog using "excerpts/simulations2", replace
imperfectiv y1 (x=z), noassumption4
imperfectiv y1 (x=z)

sjlog close, replace 
