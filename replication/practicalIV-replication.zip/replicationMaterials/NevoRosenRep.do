sjlog using "./excerpts/NevoRosen", replace
use NevoRosen2012.dta, clear

replace addv=addv/10
local w addv bd1 bd2 bd3 bd4 bd5 bd6 bd7 bd8 bd9 bd10 bd11 bd12 bd13 bd14 bd15 bd16 bd17 bd18 bd19 bd20 bd21 bd22 bd23 bd24 dd2 dd3 dd4 dd5 dd6 dd7 dd8 dd9 dd10 dd11 dd12 dd13 dd14 dd15 dd16 dd17 dd18 dd19 dd20 sfdum
gen qavgpo=p_bs
replace qavgpo=p_sf if city==7

imperfectiv y `w' (price=qavgp qavgpo), prop5 noassumption exogvars(`w')
imperfectiv y `w' (price=qavgp qavgpo), prop5 exogvars(addv)
sjlog close, replace
