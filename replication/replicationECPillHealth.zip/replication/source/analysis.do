/* analysis.do v0.00            damiancclarke              yyyy-mm-dd:2018-11-16
----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8

This file generates descriptive figures, tables and graphical results presented
in the paper
    "Access to The Emergency Contraceptive Pill Improves Women's Health:
                          Evidence from Chile"
by Damian Clarke and Viviana Salinas.

This file uses a number of external ados, which are installed automatically on
lines xx-yy (provided internet connectivity is available).  If internet connec-
tivity is not avaialble and these ados are not installed, the file will not re-
plicate until the ados have been installed, or the computer is connected to the
internet.

This file has been written and for Stata 15 on a Unix system with no GUI.  As
such, some graph exporting commands are unnecessarily complicated, as graphs m-
ust be exported to pdf directly, rather than with Stata's graph export command.
On a windows or Mac system with GUI available these commands (which begin with
translate @graph) could be simplified significantly.

To control this file, the global MAIN on line zz should be set as the directory
on your computer where these replication materials are stored.  No other changes
should be necessary to replicate results, provided all data is available.

For optimal viewing, set indent width to 4

Contact:
  damian.clarke@protonmail.com
  damian.clarke@usach.cl

*/

vers 11
clear all
set more off
cap log close

global MAIN "~/investigacion/2018/pillHealth/replication"

global DAT "$MAIN/data/comunaLevel"
global MAP "$MAIN/data/map"
global OUT "$MAIN/results"
global LOG "$MAIN/log"

set scheme plotplainblind, permanently
graph set eps fontface "Times New Roman"


cap which scheme-plotplainblind.scheme
if _rc!=0 ssc install blindschemes
foreach ado in estout spmap {
    cap which `ado'
    if _rc!=0 ssc install `ado'
}

log using "$LOG/analysis.txt", text replace

cap mkdir "$OUT"
cap mkdir "$OUT/event"
cap mkdir "$OUT/descriptives"
cap mkdir "$LOG"

*-------------------------------------------------------------------------------
*--- (2) Descriptives
*-------------------------------------------------------------------------------
use "$DAT/pillHealthEntregas"

#delimit ;
local hvars abortion15_49 abortion15_19 haemorrhage15_49 haemorrhage15_19
            abortion20_24 abortion25_29 haemorrhage20_24 haemorrhage25_29
            abortion30_34 abortion35_39 haemorrhage30_34 haemorrhage35_39
            abortion40_44 abortion45_49 haemorrhage40_44 haemorrhage45_49;
#delimit cr

preserve
collapse (sum) birth* poblacion*, by(year)
foreach age in 15_49 15_19 20_24 25_29 30_34 35_39 40_44 45_49 {
    gen birth`age'Pop=birth`age'/poblacion`age'*1000
}
keep birth*Pop year
drop if year==2017
#delimit ;
graph twoway connected birth15_19Pop year
          || connected birth20_24Pop year
          || connected birth25_29Pop year
          || connected birth30_34Pop year
          || connected birth35_39Pop year
          || connected birth40_44Pop year,
ytitle("Births per 1,000 Women") xtitle("Year")
xlabel(2002(2)2016)
legend(order(1 "15-19" 2 "20-24" 3 "25-29" 4 "30-34" 5 "35-39" 6 "40-44"));
graph export "$OUT/fert2002_2016.eps", replace;
#delimit cr
restore

local contvars diu oral_comb oral_prog injectable condom_women condom_men
preserve
drop if year==2002
collapse `contvars', by(servicio year)
collapse (sum) `contvars', by(year)
foreach cvar of varlist `contvars' {
    format `cvar' %9.0fc
    #delimit ;
    twoway connected `cvar' year, lwidth(thick) lcolor(gs10) ms(S) mc(black)
    xlabel(2003(1)2017, angle(45)) scheme(LF3) 
    ytitle("Population Covered") xtitle("Year");
    graph export "$OUT/descriptives/`cvar'.eps", replace;
    #delimit cr
}
#delimit ;
twoway connected diu        year, ms(Oh) lcolor(gs12) ||
       connected oral_comb  year, ms(Th) lcolor(gs12) ||
       connected oral_prog  year, ms(Sh) lcolor(gs12) ||
       connected injectable year, ms(Dh) lcolor(gs12) ||
       connected condom_w   year, ms(O) lcolor(gs12) ||
       connected condom_m   year, ms(T) lcolor(gs12) 
xlabel(2003(1)2017, angle(45)) scheme(LF3) ylabel(,angle(25))
ytitle("Population Covered" "") xtitle("Year")
legend(order(1 "IUD" 2 "Pill (combined)" 3 "Pill (Progrestin only)"
             4 "Injectable "5 "Condom (women)" 6 "Condom (men)")
       cols(3));
graph export "$OUT/descriptives/all_contraceptives.eps", replace;
#delimit cr
restore

preserve
collapse (sum) `hvars' puerperium maleMorbidity, by(year)

foreach var of varlist `hvars' puerperium maleMorbidity {
    dis "`var'"
    if regexm(`"`var'"',"abortion")==1    local c "Abortion Morbidity"
    if regexm(`"`var'"',"haemorrhage")==1 local c "Haemorrhage Early in Pregnancy"
    if `"`var'"'=="puerperium" local c "Complications related to the puerperium"
    if `"`var'"'=="maleMorbidity" local c "Male morbidity (15-49 years)"
    #delimit ;
    twoway line `var' year, xline(2009) lwidth(thick)
    ||     scatter `var' year, msymbol(Sh) legend(off)
    ytitle("Inpatient Cases: `c'") xlabel(2001(2)2017) xtitle("Year");
    graph export "$OUT/descriptives/trendAll_`var'.eps", replace;
    #delimit cr
}
restore


bys comuna (year): gen pillYears = sum(pill)
gen p2009 = pillYears==1&pill==1&year==2009
gen p2010 = pillYears==1&pill==1&year==2010
gen p2011 = pillYears==1&pill==1&year==2011
gen p2012 = pillYears==1&pill==1&year==2012
bys comuna: egen pill2009 = max(p2009)
bys comuna: egen pill2010 = max(p2010)
bys comuna: egen pill2011 = max(p2011)
bys comuna: egen pill2012 = max(p2012)

replace pildorasEntregadas=0 if pildorasEntregadas==.&year!=2017
replace pildorasNoEntregadas=0 if pildorasNoEntregadas==.&year!=2017
replace pildorasNoEntregadas=. if year==2009
gen pillPop = pildorasEntregadas/poblacion15_49*1000
gen noPillPop = pildorasNoEntregadas/poblacion15_49*1000
gen pillRejectRate = pildorasNoEntregadas/pildorasEntregadas

gen pp = pillPop if year>2009
bys comuna: egen meanPill = mean(pp)
sum meanPill, d

gen q1 = meanPill<1.66
gen q2 = meanPill>=1.66&meanPill<3.85
gen q3 = meanPill>=3.85

replace party = "missing" if party==""
tab party, gen(_parties)
replace mujer=3 if mujer==.
tab mujer, gen(_sexo)


*-------------------------------------------------------------------------------
*--- (2) Summary statistics
*-------------------------------------------------------------------------------
preserve
collapse pill (sum) pildorasEntregadas pildorasNoEntregadas, by(comuna year)
collapse (sum) pill pildorasEntregadas pildorasNoEntregadas, by(year)

#delimit ;
twoway connected pildorasEntregadas year if year!=2017,
  lwidth(thick) lcolor(gs10) ms(S) mc(black) ||
       connected pill year, lpattern(dash) yaxis(2) scheme(LF3) ms(Th)
lwidth(thick) xlabel(2002(1)2017, angle(45)) xsize(5)
ytitle("Pills Disbursed", axis(1)) ytitle("Municipalities Prescribing", axis(2))
legend(order(1 "Pills Disbursed" 2 "Municipalities Prescribing"));
graph export "$OUT/descriptives/pillRollout.eps", replace;
#delimit cr
restore

generat pillENJUV = 1 if pillNCP==1&year>=2010
replace pillENJUV = 0 if pillNCP==1&year<2010|pillNCP==0


lab var abortion15_49 "Number of Cases of Abortion Related Morbidity (15-49)"
lab var haemorrhage15_49 "Number of Cases of Haemorrhage Early in Pregnancy (15-49)"
lab var maleMorbidity "Number of Cases of all Cause Male Morbidity (15-49)"
lab var puerperium "Number of Complications Related to the Puerperium (15-49)"
lab var birth15_49 "Number of Births (15-49)"
lab var poblacion15_49 "Population of Fertile-Aged Women (15-49)"
lab var poblacionMale15_49 "Population of Fertile-Aged Men (15-49)"
lab var year "Year"
lab var pill "Municipality Has Pill Availability"
lab var pildorasEntregadas "Number of Pills Disbursed"
lab var pildorasNoEntregadas "Number of Pills Refused"
lab var pillPop "Pills Disbursed per 1000 Women"
lab var noPillPop "Pill Requests Rejected per 1000 Women"
lab var pillNCP "Pill Reported in ENJUV surveys"

gen rateAbort = abortion15_49/poblacion15_49*100000
gen rateHaem  = haemorrhage15_49/poblacion15_49*100000
gen rateBirth = birth15_49/poblacion15_49*1000
gen rateMaleHealth = maleMorbidity/poblacionMale15_49*100000
gen ratePuer  = puerperium/poblacion15_49*100000

lab var rateAbort "Abortion Morbidity per 100,000 Reproductive Age Women"
lab var rateHaem  "Rate of Haemorrhage per 100,000 Reproductive Age Women"
lab var rateBirth "Birth Rate per 1,000 Reproductive Age Women"
lab var rateMaleH "Rate of Male Morbidity per 100,000 15-49 year-old Men"
lab var ratePuer  "Rate of Complications Related to the Puerperium"

preserve
keep if year!=2017
#delimit ;
estpost sum abortion15_49 haemorrhage15_49 puerperium maleMorbidity
poblacion15_49 poblacionMale15_49 rateAbort rateHaem ratePuer rateMaleH
pill pildorasEntregadas pildorasNoEntregadas pillPop noPillPop;
estout using "$OUT/descriptives/SumStats.tex", replace label style(tex)
cells("count mean(fmt(2)) sd(fmt(2)) min(fmt(0)) max(fmt(0))")
collabels(, none) mlabels(, none);
#delimit cr


replace pillPop = . if year<2009
gen pillYear = 2009 if pill2009==1
replace pillYear = 2010 if pill2010==1
replace pillYear = 2011 if pill2011==1
replace pillYear = 2012 if pill2012==1

collapse pillPop pillYear, by(comuna nombre_comuna)
replace nombre_comuna = trim(nombre_comuna)
replace nombre_comuna = subinstr(nombre_comuna, "  ", " ", .)
replace nombre_comuna = "Buin" if nombre_comuna=="Buín"
replace nombre_comuna = "Cochamí" if nombre_comuna=="Cochamó"
replace nombre_comuna = "Hijuelas" if nombre_comuna=="Hijuela"
replace nombre_comuna = "Independencia" if nombre_comuna=="Inpendencia"
replace nombre_comuna = "Calera" if nombre_comuna=="La Calera"
replace nombre_comuna = "Los Alamos" if nombre_comuna=="Los Álamos"
replace nombre_comuna = "Los Angeles" if nombre_comuna=="Los Ángeles"
replace nombre_comuna = "Marchigüe" if nombre_comuna=="Marchihue"
replace nombre_comuna = "Maullén" if nombre_comuna=="Maullín"
replace nombre_comuna = "O'Higgins" if nombre_comuna=="O´Higgins"
replace nombre_comuna = "Paihuano" if nombre_comuna=="Paiguano"
replace nombre_comuna = "Peñalolén" if nombre_comuna=="Peñalolen"
replace nombre_comuna = "Ranquil" if nombre_comuna=="Ránquil"

rename comuna COD_COMUNA
rename nombre_comuna nom_com
merge 1:1 nom_com using "$MAP/ChileLite"
drop if _merge!=3

gen adoptTime = pillYear - 2008

rename _id _ID
drop if _ID==242|_ID==336|_ID==346

#delimit ;
spmap adoptTime using "$MAP/ChileLiteCoords", id(_ID) legstyle(2)
legend(symy(*2.8) symx(*2.8) size(*3.5) rowgap(1) title("Rollout", size(*2.5))
       lab(5 "2012") lab(4 "2011")
       lab(3 "2010") lab(2 "2009") position(11))
clmethod(custom) clbreaks(0 1.1 2.1 3.1 4.1)
fcolor(Spectral);
graph export "$OUT/Rollout_Time.eps", replace;

gen RM = regexm(nom_reg , "Santiago");
spmap adoptTime if RM==1 using "$MAP/Chile_coords", id(_ID) legstyle(2)
legend(symy(*1) symx(*1) size(*1.2) rowgap(1) title("Rollout")
       lab(5 "2012") lab(4 "2011")
       lab(3 "2010") lab(2 "2009") position(11))
clmethod(custom)  clbreaks(0 1.1 2.1 3.1 4.1)
fcolor(Spectral);
graph export "$OUT/Rollout_Time_RM.eps", replace;

format pillPop %5.2f;
spmap pillPop using "$MAP/ChileLiteCoords", id(_ID) legstyle(2)
legend(symy(*2.8) symx(*2.8) size(*3.5) rowgap(1)
       title("Disbursements", size(*1.5)) position(11))
fcolor(Spectral);
graph export "$OUT/PillIntensity.eps", replace;

spmap pillPop if RM==1 using "$MAP/Chile_coords", id(_ID) legstyle(2)
legend(symy(*1) symx(*1) size(*1.2) rowgap(1)
       title("Pill Disbursements", size(*0.8)) position(11))
fcolor(Spectral);
graph export "$OUT/PillIntensity_RM.eps", replace;
#delimit cr
restore



*-------------------------------------------------------------------------------
*--- (3) DD regressions
*-------------------------------------------------------------------------------
local xvar pillPop
local c _parties* _sexo*
foreach age in 15_49 15_19 20_24 25_29 30_34 35_39 40_44 45_49 {
    gen birth`age'Pop=birth`age'/poblacion`age'*1000
    gen haem`age'Pop =haemorrhage`age'/poblacion`age'*100000
    gen abort`age'Pop=abortion`age'   /poblacion`age'*100000

    local se abs(comuna) cluster(comuna)
    eststo: areg birth`age'Pop  i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum birth`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
    eststo: areg haem`age'Pop   i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum haem`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
    eststo: areg abort`age'Pop  i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum abort`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
}

lab var pillPop "Pills Disbursed per 1000 Women"
#delimit ;
esttab est1 est4 est7 est10 est13 est16 est19 est22 using "$OUT/DD_birth.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));

esttab est2 est5 est8 est11 est14 est17 est20 est23 using "$OUT/DD_haem.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));

esttab est3 est6 est9 est12 est15 est18 est21 est24 using "$OUT/DD_abort.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));
#delimit cr
estimates clear


local xvar noPillPop
foreach age in 15_49 15_19 20_24 25_29 30_34 35_39 40_44 45_49 {
    local se abs(comuna) cluster(comuna)
    eststo: areg birth`age'Pop  i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum birth`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
    eststo: areg haem`age'Pop   i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum haem`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
    eststo: areg abort`age'Pop  i.year `xvar' `c' [aw=poblacion`age'], `se'
    sum abort`age'Pop if e(sample)==1
    estadd scalar mean=r(mean)
}
lab var noPillPop "Pill Requests Rejected per 1000 Women"
#delimit ;
esttab est1 est4 est7 est10 est13 est16 est19 est22 using "$OUT/DD_birth_noPill.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));

esttab est2 est5 est8 est11 est14 est17 est20 est23 using "$OUT/DD_haem_noPill.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));

esttab est3 est6 est9 est12 est15 est18 est21 est24 using "$OUT/DD_abort_noPill.tex",
b(%-9.3f) se(%-9.3f) noobs keep(`xvar') nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));
#delimit cr
estimates clear

eststo: areg birth15_49 i.year noPillPop [aw=poblacion15_49], `se'
sum birth15_49Pop if e(sample)==1
estadd scalar mean=r(mean)
eststo: areg birth15_49 i.year noPillPop [aw=poblacion15_49] if year>=2009, `se'
sum birth15_49Pop if e(sample)==1
estadd scalar mean=r(mean)

eststo: areg haem15_49 i.year noPillPop [aw=poblacion15_49], `se'
sum haem15_49Pop if e(sample)==1
estadd scalar mean=r(mean)
eststo: areg haem15_49 i.year noPillPop [aw=poblacion15_49] if year>=2009, `se'
sum haem15_49Pop if e(sample)==1
estadd scalar mean=r(mean)

eststo: areg abort15_49 i.year noPillPop [aw=poblacion15_49], `se'
sum abort15_49Pop if e(sample)==1
estadd scalar mean=r(mean)
eststo: areg abort15_49 i.year noPillPop [aw=poblacion15_49] if year>=2009, `se'
sum abort15_49Pop if e(sample)==1
estadd scalar mean=r(mean)

lab var pillRejectRate "Pills Rejected/Pills Disbursed"

#delimit ;
esttab est3 est4 est5 est6 using "$OUT/DD_rejections.tex",
b(%-9.3f) se(%-9.3f) noobs keep(noPillPop) nonotes nogaps
mlabels(, none) nonumbers style(tex) fragment replace noline label
starlevel ("*" 0.10 "**" 0.05 "***" 0.01)
stats(N mean, fmt(%9.0gc %5.3f) label("\\ Observations" "Mean of Dependent Variable"));
#delimit cr


*-------------------------------------------------------------------------------
*--- (4) Event study (Full)
*-------------------------------------------------------------------------------
gen voteMiss = votop==.
replace votop=0.5 if votop==.

gen pillyear     = 2009 if pill2009==1
replace pillyear = 2010 if pill2010==1
replace pillyear = 2011 if pill2011==1
replace pillyear = 2012 if pill2012==1

gen pillAdopt = year - pillyear
gen reverse   = year>pillyear & pill == 0


foreach y of numlist 0(1)10 {
    gen PillN`y'=pillAdopt==-`y'
    gen PillP`y'=pillAdopt==`y'
}
drop PillN0 PillN1 PillP9 PillP10


gen oralpill=oral_comb+oral_prog
gen condoms =condom_women+condom_men
gen totalModern = oralpill+diu+injectable
bys servicio year: egen populationDenom = total(poblacion15_49)
foreach var of varlist diu oralpill injectable condoms totalModern {
    gen `var'_rate=`var'/populationDenom
}
sum *_rate


local X1 
local X2 _parties* _sexo* votop voteMiss
local X3 totalModern_rate
local fname
local gopts name(Graph) xsize(8.00) ysize(4.00) tmargin(3.50) lmargin(0.25)

foreach c of numlist 1 2 3 {
    dis "Running event studies with controls X`c'"
    foreach age in 15_19 20_24 25_29 30_34 35_39 40_44 45_49 15_49 { 
        local leads PillN9 PillN8 PillN7 PillN6 PillN5 PillN4 PillN3 PillN2
        local lags  PillP0 PillP1 PillP2 PillP3 PillP4 PillP5 PillP6 PillP7 PillP8 
        local se abs(comuna) cluster(comuna)
        local wts [aw=poblacion`age']
        if `c'==2 local fname polcontrols
        if `c'==3 local fname contcontrols

        foreach var in haem abort birth {
            areg `var'`age'Pop i.year `leads' `lags' `X`c'' `wts', `se'
            test `leads'
            test `lags'
        
            preserve
            gen PointEst = .
            gen UB       = .
            gen LB       = .
            gen UB2       = .
            gen LB2       = .
            gen time     = .
            local j = 1
            local t = -9
            foreach lead in `leads' {
                replace PointEst = _b[`lead'] in `j'
                replace time = `t' in `j'
                replace LB = _b[`lead']  + invttail(e(N),0.975)*_se[`lead'] in `j'
                replace UB = _b[`lead']  + invttail(e(N),0.025)*_se[`lead'] in `j'    
                replace LB2 = _b[`lead'] + invttail(e(N),0.950)*_se[`lead'] in `j'
                replace UB2 = _b[`lead'] + invttail(e(N),0.050)*_se[`lead'] in `j'    
                local ++j
                local ++t
            }
            replace time     = `t' in `j'
            replace PointEst = 0 in `j'
            replace LB       = 0 in `j'
            replace UB       = 0 in `j'
            replace LB2       = 0 in `j'
            replace UB2       = 0 in `j'
            local ++t
            local ++j
            foreach lag in `lags' {
                replace PointEst = _b[`lag'] in `j'
                replace time = `t' in `j'
                replace LB = _b[`lag']  + invttail(e(N),0.975)*_se[`lag'] in `j'
                replace UB = _b[`lag']  + invttail(e(N),0.025)*_se[`lag'] in `j'
                replace LB2 = _b[`lag'] + invttail(e(N),0.950)*_se[`lag'] in `j'
                replace UB2 = _b[`lag'] + invttail(e(N),0.050)*_se[`lag'] in `j'
                local ++j
                local ++t
            }
            
            #delimit ;
            twoway rarea LB UB  time, color(gs14%40) yline(0, lcolor(red))
               || rarea LB2 UB2 time, color(gs14%70) 
               || scatter PointEst time in 1/`j',
            xline(-1, lcolor(black) lpattern(solid))
            xlabel(-9(1)8) legend(order(3 "Point Estimate" 1 "95% CI"  2 "90% CI"))
            ytitle("Morbidity per 100,000 Women") xsize(8)
            xtitle("Years to Arrival of Emergency Contraceptive Pill");
            #delimit cr
            translate @Graph $OUT/event/`var'`age'`fname'.pdf, `gopts'        
            restore
        }
    }

    ***"PLACEBO" OUTCOMES
    cap gen maleMorbidityPop = maleMorbidity/poblacionMale15_49*100000
    foreach var of varlist femaleMorbidity puerperium {
        cap gen `var'Pop = `var'/poblacion15_49*100000   
    }
    foreach var of varlist maleMorbidity femaleMorbidity puerperium {
        local wts [aw=poblacion15_49]
        if `"`var'"' == "maleMorbidity" local wts [aw=poblacionMale15_49 ]
        areg `var'Pop i.year `leads' `lags' `X`c'' `wts', `se'
        test `leads'
        test `lags'
    
        preserve
        gen PointEst = .
        gen UB       = .
        gen LB       = .
        gen UB2       = .
        gen LB2       = .
        gen time     = .
        local j = 1
        local t = -9
        foreach lead in `leads' {
            replace PointEst = _b[`lead'] in `j'
            replace time = `t' in `j'
            replace LB = _b[`lead']  + invttail(e(N),0.975)*_se[`lead'] in `j'
            replace UB = _b[`lead']  + invttail(e(N),0.025)*_se[`lead'] in `j'    
            replace LB2 = _b[`lead'] + invttail(e(N),0.950)*_se[`lead'] in `j'
            replace UB2 = _b[`lead'] + invttail(e(N),0.050)*_se[`lead'] in `j'    
            local ++j
            local ++t
        }
        replace time     = `t' in `j'
        replace PointEst = 0 in `j'
        replace LB       = 0 in `j'
        replace UB       = 0 in `j'
        replace LB2       = 0 in `j'
        replace UB2       = 0 in `j'
        local ++t
        local ++j
        foreach lag in `lags' {
            replace PointEst = _b[`lag'] in `j'
            replace time = `t' in `j'
            replace LB = _b[`lag']  + invttail(e(N),0.975)*_se[`lag'] in `j'
            replace UB = _b[`lag']  + invttail(e(N),0.025)*_se[`lag'] in `j'
            replace LB2 = _b[`lag'] + invttail(e(N),0.950)*_se[`lag'] in `j'
            replace UB2 = _b[`lag'] + invttail(e(N),0.050)*_se[`lag'] in `j'
            local ++j
            local ++t
        }
    
        #delimit ;
        twoway rarea LB UB  time, color(gs14%40) yline(0, lcolor(red))
           || rarea LB2 UB2 time, color(gs14%70) 
           || scatter PointEst time in 1/`j', xline(-1, lcolor(black) lpattern(solid))
        xlabel(-9(1)8) legend(order(3 "Point Estimate" 1 "95% CI"  2 "90% CI"))
        ytitle("Morbidity per 100,000") xsize(8)
        xtitle("Years to Arrival of Emergency Contraceptive Pill");
        #delimit cr
        translate @Graph $OUT/event/`var'`fname'.pdf, name(Graph)
        restore
    }


    ***Event studies based on terciles.  3 sets of lags and leads
    foreach y of numlist 0(1)10 {
        foreach num of numlist 1 2 3 {
            cap gen PillN`y'_q`num'=pillAdopt==-`y'&q`num'==1
            cap gen PillP`y'_q`num'=pillAdopt==`y' &q`num'==1
            #delimit ;
            local leads`num' PillN9_q`num' PillN8_q`num' PillN7_q`num' PillN6_q`num'
                             PillN5_q`num' PillN4_q`num' PillN3_q`num' PillN2_q`num';
            local lags`num'  PillP0_q`num' PillP1_q`num' PillP2_q`num' PillP3_q`num'
                             PillP4_q`num' PillP5_q`num' PillP6_q`num' PillP7_q`num'
                             PillP8_q`num';
            #delimit cr
        }
    }
    drop PillN0_* PillN1_* PillP9_* PillP10_*
    local leads `leads1' `leads2' `leads3'
    local lags  `lags1'  `lags2'  `lags3'
    
    foreach var in haem15_49Pop abort15_49Pop maleMorbidityPop femaleMorbidityPop puerperiumPop {
        local wts [aw=poblacion15_49]
        if `"`var'"' == "maleMorbidityPop" local wts [aw=poblacionMale15_49]
        areg `var' i.year `leads' `lags' `X`c'' `wts', `se'

        preserve
        local jit = -0.34
        foreach num of numlist 1(1)3 {
            local jit = `jit'+0.17
            gen time_`num' = .    
            gen PointEst_`num' = .
            gen UB_`num'       = .
            gen LB_`num'       = .
            local j = 1
            local t = -9
            foreach lead in `leads`num'' {
                replace PointEst_`num' = _b[`lead'] in `j'
                replace time_`num' = `t'+`jit' in `j'
                replace LB_`num' = _b[`lead']  + invttail(e(N),0.975)*_se[`lead'] in `j'
                replace UB_`num' = _b[`lead']  + invttail(e(N),0.025)*_se[`lead'] in `j'    
                local ++j
                local ++t
            }
            replace time_`num'     = `t' in `j'
            replace PointEst_`num' = 0 in `j'
            replace LB_`num'       = 0 in `j'
            replace UB_`num'       = 0 in `j'
            local ++t
            local ++j
            foreach lag in `lags`num'' {
                replace PointEst_`num' = _b[`lag'] in `j'
                replace time_`num' = `t'+`jit' in `j'
                replace LB_`num' = _b[`lag']  + invttail(e(N),0.975)*_se[`lag'] in `j'
                replace UB_`num' = _b[`lag']  + invttail(e(N),0.025)*_se[`lag'] in `j'
                local ++j
                local ++t
            }
        }
        #delimit ;
        twoway rcap LB_1 UB_1 time_1, lcolor(gs12) yline(0, lcolor(red))
          || connected PointEst_1 time_1 in 1/`j', lcolor(black) lpattern(dash) ms(Oh)
          || rcap LB_2 UB_2 time_2, lcolor(gs12) 
          || connected PointEst_2 time_2 in 1/`j', lcolor(black) lpattern("_-") ms(T)
          || rcap LB_3 UB_3 time_3, lcolor(gs12)
          || connected PointEst_3 time_3 in 1/`j', ms(sh) lpattern(solid) lwidth(thick)
        xline(-1, lcolor(black) lpattern(solid))
        legend(order(2 "Low EC Pill" 4 "Medium EC Pill" 6 "High EC Pill" 1 "95% CI"))
        xlabel(-9(1)8) ytitle("Morbidity per 100,000 Women") xsize(7.6) scheme(s1mono)
        xtitle("Years to Arrival of Emergency Contraceptive Pill");
        graph export "$OUT/event_`var'_intensity`fname'.eps", replace;
        #delimit cr
        restore
    }
}



*-------------------------------------------------------------------------------
*--- (5) Clean up
*-------------------------------------------------------------------------------
log close
