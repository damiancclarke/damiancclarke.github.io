--------------------------------------------------------------------------------
Replication Materials: Implementing the Panel Event Study
Damian Clarke and Kathya Tapia Schythe
December, 2020
--------------------------------------------------------------------------------

This folder contains replication materials for the paper "Implementing the Panel
Event Study" revised for the Stata Journal. The folder contains four files apart
from this README:
 - eventdd.ado: The main ado described in the paper
 - eventdd.sthlp: Documentation for this program
 - eventdd_estat.ado: Post-estimation commands related to eventdd.ado
 - panelEventReplication.do: Replication of all the materials in the paper

To replicate the results documented in the paper, simply run the file
panelEventReplication.do in Stata (version >=13.0).  This ado requires a number
of additional programs which can be installed directly from the SSC, namely:
> reghdfe
> boottest
> matsort
If these are not available on the system where this script is located, they
should be installed prior to running the do file. Notes at the head of the file
panelEventReplication.do provide full information related to the replication of
this file.

In case of queries, please contact:
 dclarke@fen.uchile.cl
 kathya.tapia@usach.cl

