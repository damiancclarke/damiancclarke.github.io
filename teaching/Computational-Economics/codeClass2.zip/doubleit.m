function answer = doubleit(W)
% doubleit takes a single argument, and returns 
% the value multiplied by 2
% 

% Here is the step where we double the argument
answer = 2*W;

end
