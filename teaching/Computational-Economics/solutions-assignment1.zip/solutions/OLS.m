function [betahat, se, t, p, CI, seWhite, N] = OLS(y, X)
%--------------------------------------------------------------------------------
% PURPOSE: Function to estimate an ordinary least squares (OLS)
%          regression of a dependent variable y on a series of independent
%          variables X.
%--------------------------------------------------------------------------------
% INPUTS:  y: N-by-1 dependent variable
%          X: N-by-K independent variable
%--------------------------------------------------------------------------------
% OUTPUTS: betahat: K-by-1 regression coefficients
%          se: K-by-1 standard errors associated with coefficients 
%          t: K-by-1 t-statistic associated with each parameter
%          p: K-by-1 p-value associated with each t-statistic
%          CI: K-by-2 Upper and lower 95% confidence intervals
%          seWhite: K-by-1 Robust standard errors associated with coefficients 
%          N: Scalar value indicating number of observations
%--------------------------------------------------------------------------------

%% (1) Compute regression coefficients using lm divide and dimensions
betahat = X\y; 
N = length(y);
K = size(X,2);

%% (2) Calculate standard errors and Robust standard errors
uhat     = y - X*betahat;
VarCovar = uhat'*uhat/(N-K)*inv(X'*X);
se   = sqrt(diag(VarCovar));

%below is White's standard errors
VarCovarW = inv(X'*X)*(X'*diag(uhat.^2)*X)*inv(X'*X); 
seWhite   = sqrt(diag(VarCovarW));
%if wanting to replicate Stata's standard errors, the small sample correction
%below should be implemented
seWhite   = sqrt(diag(N/(N-K)*VarCovarW));


%% (3) Conduct hypothesis test that beta = 0
t = betahat./se; 

%% (4) Calculate p-vaules associated with t-statistics
p = 2*(1 - tcdf(abs(t), N-K)) ; 

%% (5) Generate 95% Confidence Interval
CI = [betahat + tinv(0.025,N-K)*se, betahat + tinv(0.975,N-K)*se];

%% (6) Tabulate results as output
format;
Rows = {'y = mpg', 'Coef.', 'Std. Err.', 't', 'P>|t|', '[95% Conf. Interval]'};
table({'Price'; 'weight'; '_cons'}, betahat, se, t, p, CI, 'VariableNames', Rows)



return


