function exportTeX(beta, se, N)
%--------------------------------------------------------------------------------
% PURPOSE: This is a very preliminary function to export regression coefficients
%          to a TeX file.  This is not at all a generalizable function, as the
%          below only works in the case that there are two regressions 
%          coefficients and standard errors stored in beta and se, and these
%          must have three variables.  A much more generalizable function can
%          be written with loops, which will be introduced after this assignment,
%          so are not used here
%--------------------------------------------------------------------------------
% INPUTS:  beta: 3-by-2 OLS estimates from two separate regressions
%          se:   3-by-2 standard errors corresponding to OLS estimates
%--------------------------------------------------------------------------------
% OUTPUTS: None.  Table written to system called regTable.tex
%--------------------------------------------------------------------------------


%% (1) Open file and make writable
rfile = fopen('regTable.tex', 'w') ;

%% (2) Write table header
fprintf(rfile,'\\begin{tabular}{lcc} \n \\toprule \n')
fprintf(rfile,' & (1) & (2) \\\\ \n & mpg & mpg \\\\ \\midrule \n');

%% (3) Write regression results
fprintf(rfile,' Price     &  %6.4f  &  %6.4f  \\\\ \n', beta(1,:));
fprintf(rfile,'           & (%6.4f) & (%6.4f) \\\\ \n', se(1,:));
fprintf(rfile,' Weight    &  %6.4f  & %6.4f   \\\\ \n', beta(2,:));
fprintf(rfile,'           & (%6.4f) & (%6.4f) \\\\ \n', se(2,:));
fprintf(rfile,' Constant  &  %6.4f  & %6.4f   \\\\ \n', beta(3,:));
fprintf(rfile,'           & (%6.4f) & (%6.4f) \\\\ \n', se(3,:));
fprintf(rfile,'\\midrule \n');
fprintf(rfile,'Observations& %d & %d  \\\\ \\bottomrule \n', N, N);


%% (3) Table end, and close file
fprintf(rfile,"end{tabular}");
fclose(rfile);

return




