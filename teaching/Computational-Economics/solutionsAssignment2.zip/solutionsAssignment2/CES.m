function u = CES(X)
% The function CES takes a single argument X which should be a vector
% of consumption of goods x1 and x2.  It returns the utility as a scalar
% value u, assuming a Constant Elasticity of Substition utility function
% and parameter rho = 0.6.

rho = 0.6
x1 = X(1);
x2 = X(2);
u = -(x1^rho+x2^rho)^(1/rho)

end