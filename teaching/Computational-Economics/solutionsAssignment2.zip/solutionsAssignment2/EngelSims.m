%This script resolves question 1 of the assignment 2 in the MRes module
% Research methods 2.  There are many possible ways to resolve these 
% questions, and the below is one possible example

clear;
clc;

%----------------------------------------------------------------------
% Part (a) simulate variation in income (Cobb Douglas, no limits)
%----------------------------------------------------------------------
x0      = [1,1];                % Initial guess for optimization. 
P       = [1,2];                % Fixed prices for goods 1 and 2.
c       = NaN(51, 2);           % Pre-allocated matrix for results to be stored.
opts    = optimset('algorithm', 'sqp', 'display', 'off'); % Same options as ConsumptionSim.
Inc     = NaN(51, 1);           % Pre-allocated vector for income

for i = 50:100
    j = i-49;
    Inc(j)  = i;
    c(j, :) = fmincon(@CobbDouglas, x0, P, i, [], [], [], [], [], opts)
end
% The result c contains optimized amonts of consumption, summing to 
% between 50 and 100 (depending on income).

% Plot the Engel curves for both goods, which shows how demand changes
% (holding prices fixed) when income changes.

% Engel curve for x1:
subplot(1, 2, 1)
line(c(:,1), Inc)
xlabel('Good 1 Consumption')
ylabel('Income')

% Engel curve for x2: 
subplot(1, 2, 2)
line(c(:,2), Inc)
xlabel('Good 2 Consumption')
ylabel('Income')


%----------------------------------------------------------------------
% Part (b) simulate variation in income with purchase limit 
%----------------------------------------------------------------------
c2       = NaN(51, 2)      % Pre-allocated matrix for results to be stored.
Inc2     = NaN(51, 1)      % Pre-allocated vector for income
u        = NaN(51, 1)      % Pre-allocated vector for utility

for i = 50:10
    j = i-49;
    Inc2(j)  = i;
    [c2(j, :),u(j,:)] = fmincon(@CobbDouglas, x0, P, i, [], [], [], [Inf,20], [], opts)
end
u = u*-1 % Make utilty positive given minimization rather than maximization 
clf

% Plot the Engel curves for both goods, which shows how demand changes
% (holding prices fixed) when income changes, as well as plot income and
% utility.

% Engel curve for x1:
subplot(1, 3, 1)
line(c2(:,1), Inc2)
xlabel('Good 1 Consumption')
ylabel('Income')

% Engel curve for x2: 
subplot(1, 3, 2)
line(c2(:,2), Inc2)
xlabel('Good 2 Consumption')
ylabel('Income')

subplot(1, 3, 3)
scatter(u, Inc2)
xlabel('Utility')
ylabel('Income')


%----------------------------------------------------------------------
% Part (c) simulate variation in income with CES function 
%----------------------------------------------------------------------
c3       = NaN(51, 2);
Inc3     = NaN(51, 1);

for i = 50:100
    j = i-49;
    Inc3(j)  = i;
    c3(j, :) = fmincon(@CES, x0, P, i, [], [], [], [], [], opts)
end

% Engel curve for x1:
subplot(1, 2, 1)
line(c3(:,1), Inc3)
xlabel('Good 1 Consumption')
ylabel('Income')

% Engel curve for x2: 
subplot(1, 2, 2)
line(c3(:,2), Inc3)
xlabel('Good 2 Consumption')
ylabel('Income')
