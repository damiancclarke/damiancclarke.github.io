%This script resolves question 2 of the assignment 2 in the MRes module
% Research methods 2.  There are many possible ways to resolve these 
% questions, and the below is one possible example
clear

%-------------------------------------------------------------------------
%--- (a) Refer to probitLL.m 
%-------------------------------------------------------------------------

%-------------------------------------------------------------------------
%--- (b) Read in data and estimate probit parameters using fminunc 
%-------------------------------------------------------------------------
DataIn  = dlmread('auto.csv');
X       = DataIn(:, 2:3);
X       = [X, ones(74, 1)];
y       = DataIn(:, 1);
y2      = y>20;

opt = optimset('TolFun',1E-20,'TolX',1E-20);
beta = fminunc(@(theta)probitLL(theta,y2,X), [0,0,0]',opt)


%-------------------------------------------------------------------------
%--- (c) Run 'reps' bootstraps to estimate standard errors 
%-------------------------------------------------------------------------
reps            = 2000;
rng(8225)
BootstrapBeta   = NaN(reps, 3);
opt = optimset('TolFun',1E-20,'TolX',1E-20,'display', 'off');


tic
for count = 1:reps
    MyIndex     = round(rand(74, 1) * 74 + 0.5);
     
    BootstrapX  =  X(MyIndex, :);
    BootstrapY  = y2(MyIndex, :);
    
    BootstrapBeta(count, :)     = fminunc(@(theta)probitLL(theta,...
        BootstrapY,BootstrapX), [0,0,0]',opt);
end
toc

[beta, mean(BootstrapBeta)', std(BootstrapBeta)']