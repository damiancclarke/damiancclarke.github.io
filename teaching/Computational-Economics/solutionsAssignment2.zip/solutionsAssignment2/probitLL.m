function ll = probitLL(beta,y,X)

    ll = -sum(y'*log(normcdf(X*beta))+(1-y)'*log(1-normcdf(X*beta)));

end