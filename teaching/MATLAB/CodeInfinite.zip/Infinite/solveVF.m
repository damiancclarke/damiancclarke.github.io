%======================================================================
%=== (1) Plot analytical solution
%======================================================================
Beta = 0.9; alpha = 0.65; theta = 1.2; aB = alpha*Beta;
K = linspace(1e-6,100,100);

E = alpha/(1-aB);
F = 1/(1-Beta)*(log(theta*(1-aB))+aB*log(aB*theta));
soln = E*log(K)+F;

plot(K,soln, '-k', 'LineWidth', 3)
axis([0 100 -15 10])
hold on

%======================================================================
%=== (2) Plot 10 value function iterations
%======================================================================
TV = [zeros(100,1) NaN(100,9)];
for iter = 1:10
    fprintf('Iteration number %d\n',iter)
    TV(:,iter+1)=iterateVF(TV(:,iter),100);
end

plot(K,TV)
xlabel('Amount of Capital', 'FontSize', 12)
ylabel('Value Function', 'FontSize', 12)
title('Value Function Iteration', 'FontSize', 14)
