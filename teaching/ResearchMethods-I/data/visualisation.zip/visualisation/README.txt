--------------------------------------------------------------------------------
README.txt for "Exposure to Wildfires"
Damian Clarke, Author 2
dcc213@exeter.ac.uk, email 2
--------------------------------------------------------------------------------

This project measures exposure to wildfires in Chile using data on wildfires and
their duration and wind direction. It relies on two datasets provided in Stata's
(dta) format.  This is fires2021 which contains a line for each 3 hour period in
which a fire occurs, for each municipality within 50km of the fire, along with
its distance and direction to the fire. It also contains a file u10_v10_2021.dta
which contains the wind direction and speed in grids over the country at each 3
hour time period in 2021.

The project structure is as follows.

|_ source/
|_ results/
|_ data/

All data are located in the data subfolder, and results are exported to the resu-
lts subfolder.  To run all code, simply go to the data subfolder and run the file
makeMaps.py.  To run this file, you will need to update a single directory locat-
ion listed on line 45 of the code.

This project was run on Python, version 3.8.10.

This project requires the following externally installed libraries, all installable from pip:
- numpy:      version 1.22.4
- pandas:     version 1.5.0
- matplotlib: version 3.5.2
- seaborn:    version 0.12.0
- geopandas:  version 0.12.2
- pyreadr:    version 0.4.7
- windrose:   version 1.8.1

For questions related to this code, contact dcc213@exeter.ac.uk.
