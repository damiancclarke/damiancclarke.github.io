# makeMaps.py                    damiancclarke             yyyy-mm-dd:2022-12-01
#---|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8
#
#   This file makes maps documenting wind bearings crossed with fire intensities
# and combines these maps into gifs.  This can all be controlled using different
# month spans and time periods in section 3.  This is run using Python 3.8.10,
# but should work with any version of Python 3 provided dependencies are install-
# ed.  All dependencies are listed in section [0] of the code.
#
# To run this code, the location of materials on the users' machine should be s-
# et (as "base") on line 45.
#
# This code can be run using the following at the command line:
#  python3 -W ignore makeMaps.py
#
# The -W ignore flag is because error messages are thrown when no fires occur in
# a given moment and the map of fires is empty.  If -W ignore is not used these
# messages will simply be printed on the screen.


################################################################################
### [0] Imports
################################################################################
import numpy as np
import pandas as pd
import os

import shapefile as shp
import matplotlib.pyplot as plt
import seaborn as sns
import geopandas as gpd
import pyreadr
from windrose import WindroseAxes

from PIL import Image
import glob
from datetime import date, timedelta

import matplotlib.colors as colors
from matplotlib.patches import Patch

sns.set(style="whitegrid", palette="pastel", color_codes=True)
sns.mpl.rc("figure", figsize=(10,6))

base = "/home/damian/trabajo/Teaching/Exeter/ResearchMethods-I/visualisation/"

################################################################################
### [1] First explore a basic map with random data
################################################################################
sf = gpd.read_file(base+"data/comunas.shp")
sf['cvar']=np.random.normal(0,1,len(sf))
sf = sf.to_crs('epsg:4326')


################################################################################
### [5] Bring this all together and loop over dates to make a gif
################################################################################
fires = pd.read_stata(base+"data/fires2021.dta")
fires.CUT_2018 = fires['CUT_2018'].astype('int64')
wind = pd.read_stata(base+"data/u10_v10_2021.dta")
wind.CUT_2018   = wind['CUT_2018'].astype('int64')
wind.Long       = wind['Long'].astype('float64')
wind.Lat        = wind['Lat'].astype('float64')
wind.viento_u10 = wind['viento_u10'].astype('float64')
wind.viento_v10 = wind['viento_v10'].astype('float64')

sf = gpd.read_file(base+"data/comunas.shp")
sf = sf.to_crs('epsg:4326')
sf['CUT_2018']=sf.cod_comuna
    

lat=[-76,-68]
lon=[-42,-30]           

imgs = []
for day in range(1,32):
    sday  = str(day).zfill(2)
    sdate = '2021-01-'+sday+' 15:00:00'

    print(sdate)
    firesD = fires.loc[fires['Date']==sdate]
    windD =  wind.loc[wind['Date']==sdate]

    gdf  = gpd.GeoDataFrame(firesD, geometry=gpd.points_from_xy(firesD.lo1, firesD.la1))

    both = pd.merge(firesD,windD,on="CUT_2018", how="left")
    both['windangle'] = np.mod(270-np.arctan2(both.viento_u10,both.viento_v10)*180/np.pi,360)
    both['windspeed'] = np.sqrt(np.square(both.viento_u10)+np.square(both.viento_v10))

    distance = both[['Distancia','CUT_2018']].groupby('CUT_2018').mean()
    sfD = pd.merge(sf,distance,on="CUT_2018",how="left")

    fig, ax = plt.subplots(figsize=(10, 10))
    sfD.plot(ax=ax,column='Distancia',cmap="viridis",vmin=0, vmax=50000,
        missing_kwds={
               "color": "lightgrey",
               "edgecolor": "grey",
               "label": "Missing values",
            },
            legend=True,alpha=0.7)

    scale=3
    f = gdf.plot(ax=ax, color='orange', edgecolor='black',
                 alpha=0.1,markersize=(firesD.Superficie**0.9)*scale)
    ax.set_title(sdate)

    plt.quiver(windD.Long,windD.Lat,windD.viento_u10,windD.viento_v10,
               alpha=0.6, width=0.006)
    ax.set_xlim(lat[0],lat[1])
    ax.set_ylim(lon[0],lon[1])          

    fname = base+'/results/f'+sdate+'.png'
    plt.savefig(fname,bbox_inches='tight')
    imgs.append(fname)
    plt.clf()
    
frames = []
for i in imgs:
    new_frame = Image.open(i)
    frames.append(new_frame)

fn_save = base+'results/fires.gif'
frames[0].save(fn_save, format='GIF', append_images=frames[1:],
               save_all=True, duration=300, loop=0)


