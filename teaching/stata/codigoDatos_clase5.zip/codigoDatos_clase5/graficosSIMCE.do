/*graficosSIMCE.do|Análisis Económico y Social usando Stata|yyyy-mm-dd2021-09-31     
----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8

 En este archivo, utilizaremos datos públicos de la prueba SIMCE para realizar
varios gráficos, y también mapear resultados a nivel de colegio/comuna en Chile.
Para poder replicar todo aquí, será necesario haber instalado los ado externos
del ssc: spmap y scheme-burd.  Se puede hacer esto sacando el comentario en la
línea 24 y 25.

Para poder replicar los resultados aquí, es necesario cambiar la ubicación del
directorio en la línea 27 para apuntar a la ubicación de este archivo, y las
bases de datos compartidos con el archivo en tu propio computador.

*/

*-------------------------------------------------------------------------------
*--- (0) Iniciacion 
*-------------------------------------------------------------------------------
vers 12
clear all
set more off
cap log close

ssc install spmap
ssc install scheme-burd

cd "/home/damian/trabajo/Teaching/UdeChile/introStata/2021/classes/class5/codigoDatos_clase5/"

*-------------------------------------------------------------------------------
*--- (1) Abrir datos y ejemplo basico
*-------------------------------------------------------------------------------
use simce2m2018_rbd_publica_final.dta, clear

*cod_rural_rbd   = 1-> Urbano y 2->rural
*cod_reg_rbd     = Código Región -> 1 a 16
*prom_mate2m_rbd = Puntaje promedio del establecimiento en Matemática
*prom_lect2m_rbd = Puntaje promedio del establecimiento en Lectura
*prom_nat2m_rbd  = Puntaje promedio del establecimiento en Naturaleza
*nalu_mate2m_rbd = Número de alumnos que rinde Matemáticas


twoway scatter prom_mate2m_rbd prom_lect2m_rbd
graph export "puntajeMatLect.eps", replace

#delimit ;
twoway  scatter prom_mate2m_rbd prom_lect2m_rbd, ytitle("Promedio Matematica")
  xtitle("Promedio Lectura");
graph export "puntajeMatLect-conTitulos.eps", replace;

twoway scatter prom_mate2m_rbd prom_lect2m_rbd, ytitle("Promedio Matematica")
  xtitle("Promedio Lectura") ms(Oh);
graph export "puntajeMatLect-Simbolo.eps", replace;

twoway scatter prom_mate2m_rbd prom_lect2m_rbd, ytitle("Promedio Matematica")
  xtitle("Promedio Lectura") ms(Oh) scheme(economist);
graph export "puntajeMatLect-Schema.eps", replace;
#delimit cr


*-------------------------------------------------------------------------------
*--- (2) Ejemplos más complejos
*-------------------------------------------------------------------------------
set scheme burd4

***A.- Scatter
#delimit ;
twoway scatter prom_mate2m_rbd cod_rural_rbd if cod_rural_rbd==1 & cod_reg_rbd==9,
msymbol(Oh) jitter(6) msize(vlarge) || 
      scatter prom_mate2m_rbd cod_rural_rbd if cod_rural_rbd==2 & cod_reg_rbd==9,
msymbol(X) jitter(6) msize(vlarge) xlabel(1 "Urbanos" 2 "Rurales")
title("Puntajes SIMCE Matemáticas por Establecimientos")
subtitle("Región de La Araucanía") ytitle("Puntaje Matemáticas") 
xtitle("Área Geográfica") legend(off);
graph export "scatter_mat.eps", replace;  
#delimit cr    


***B.- Lfit/Qfit
#delimit ;
twoway scatter prom_mate2m_rbd nalu_mate2m_rbd if cod_reg_rbd==4 || 
       lfit    prom_mate2m_rbd nalu_mate2m_rbd if cod_reg_rbd==4, lcolor(red)
name("lfit") title("Ajuste Lineal") ytitle("Puntaje Matemáticas") 
xtitle("Cantidad de Alumnos que Rinden") legend(off);

twoway scatter prom_mate2m_rbd nalu_mate2m_rbd if cod_reg_rbd==4 || 
       qfit    prom_mate2m_rbd nalu_mate2m_rbd if cod_reg_rbd==4, lcolor(red)
name("qfit") title("Ajuste Cuadrático") ytitle("Puntaje Matemáticas") 
xtitle("Cantidad de Alumnos que Rinden") legend(off);

graph combine lfit qfit, col(2) iscale(1) altshrink
title("SIMCE Matemáticas y Cantidad de Alumnos") subtitle("Región Coquimbo");
graph export "comp_ajuste.eps", replace;
#delimit cr  


***C.- Line/Connected
preserve 
collapse prom_lect2m_rbd prom_mate2m_rbd prom_nat2m_rbd, by(cod_reg_rbd)
#delimit ;
twoway line prom_lect2m_rbd prom_mate2m_rbd prom_nat2m_rbd cod_reg_rbd,
title("Puntajes SIMCE Promedio por Región")  ytitle("Puntaje Promedio") 
xtitle("Código Región") xlabel(1(1)16)
legend(order(1 "Lectura" 2 "Matemáticas" 3 "Naturaleza"));
graph export "line_reg.eps", replace;  

twoway connected prom_lect2m_rbd prom_mate2m_rbd prom_nat2m_rbd cod_reg_rbd,
title("Puntajes SIMCE Promedio por Región")  ytitle("Puntaje Promedio") 
xtitle("Código Región") xlabel(1(1)16) legend(order(1 "Lectura" 2 "Matemáticas" 
3 "Naturaleza"));
graph export "connected_reg.eps", replace; 
#delimit cr  
restore



preserve 
#delimit ;
collapse lec_prom=prom_lect2m_rbd mat_prom=prom_mate2m_rbd nat_prom=prom_nat2m_rbd
(min)    lec_min =prom_lect2m_rbd mat_min =prom_mate2m_rbd nat_min =prom_nat2m_rbd
(max)    lec_max =prom_lect2m_rbd mat_max =prom_mate2m_rbd nat_max =prom_nat2m_rbd,
by(cod_reg_rbd);
#delimit cr
rename cod_reg_rbd region

***D. - rarea
#delimit ;
twoway rarea mat_min mat_max region, fcolor(ltblue%45)
title("Intervalo Puntajes SIMCE Matemáticas por Región")  ytitle("Puntaje Matemáticas") 
xtitle("Código Región") xlabel(1(1)16) text(183 15.5 "Mínimo", size(medsmall)) 
text(385 15.5 "Máximo") legend(off);
graph export "rarea_mat.eps", replace;

***E. - bar
twoway bar mat_max mat_min region,
title("Puntajes SIMCE Matemáticas por Región")  ytitle("Puntaje Matemáticas") 
xtitle("Código Región") xlabel(1(1)16) legend(order(1 "Máximo" 2 "Mínimo"));
graph export "bar_mat.eps", replace;
#delimit cr    


***F. - rcap
#delimit ;
twoway rcap mat_min mat_max mat_prom if region==13 ||
       rcap lec_min lec_max lec_prom if region==13 ||
       rcap nat_min nat_max nat_prom if region==13 ||
       scatter mat_prom mat_prom if region==13, msymbol(Sh) mcolor(gray) ||
       scatter lec_prom lec_prom if region==13, msymbol(Sh) mcolor(gray) ||
       scatter nat_prom nat_prom if region==13, msymbol(Sh) mcolor(gray)
title("Intervalo Puntajes SIMCE RM") ytitle("Puntaje (Extremos)")
xtitle("Puntaje (Promedio)") 
legend(order(1 "Matemáticas" 2 "Lectura" 3 "Naturaleza" 4 "Promedio"));
graph export "rcap_rm.eps", replace;
#delimit cr 
restore

  
*-------------------------------------------------------------------------------
*--- (3) Mapas -- Estudio de caso
*-------------------------------------------------------------------------------
***A.- Mapa puntaje promedio por comunas:

use "simce2m2018_comuna_publica_final.dta", clear
rename cod_com CUT_COM
merge 1:1 CUT_COM using "mapa/ChileLite_DB"
keep if _merge==3 /*Elimina en máster Antártica*/
drop _merge

*** Matemáticas
spmap prom_mate2m_com using "mapa/ChileLiteCoords", id(_id)
graph export "mapa/SIMCEcom_mat_basica.eps", replace

#delimit ;
spmap prom_mate2m_com if cod_comuna!=5201 using "mapa/ChileLiteCoords",
id(_id) osize(vvthin vvthin vvthin vvthin vvthin) fcolor(Pastel2) clnumber(5)
ndfcolor(gs15) legend(symy(*1.7) symx(*1.7) size(*4.1) position(11))
legend(title("Puntaje Promedio Matemáticas", size(*1.1) bexpand justification(left)))
ndsize(vvthin);
graph export "mapa/SIMCEcom_mat.eps", replace;
#delimit cr

***B.- Mapa puntaje promedio por comunas con establecimientos con tamaño por
***    puntaje: Provincia Santiago excepto Lo Barnechea

/*2.935 establecimientos rinden SIMCE 2° medio, 2.911 persisten hasta 2019*/
use "simce2m2018_rbd_publica_final.dta", clear
rename rbd RBD
merge 1:1 RBD using "mapa/db_rbd.dta"
keep if _merge==3

keep RBD COD_REG COD_PROV COD_DEPROV COD_COM LATITUD LONGITUD _ID ///
prom_lect2m_rbd prom_mate2m_rbd prom_nat2m_rbd

keep if COD_PROV==131
drop if COD_COM==13115
save "./mapa/rbd_2m2018_pSANTIAGO.dta", replace

use "simce2m2018_comuna_publica_final.dta", clear
rename cod_com CUT_COM
merge 1:1 CUT_COM using "mapa/db_comunas2"
destring CUT_PROV, replace
keep if _merge==3 /*Elimina en máster Antártica*/
drop _merge
preserve
keep if CUT_PROV==131 & CUT_COM!=13115
keep x_coord y_coord COMUNA
save "mapa/label_santiago.dta", replace
restore

#delimit ;
spmap prom_mate2m_com if CUT_PROV==131 & CUT_COM!=13115 using "mapa/co_comunas2",
id(id) 
point(data("mapa/rbd_2m2018_pSANTIAGO.dta") xcoord(LONGITUD) ycoord(LATITUD));
graph export "mapa/rbdSIMCEcom_mat_pSANTIAGO_basico.eps", replace;
#delimit cr


#delimit ;
spmap prom_mate2m_com if CUT_PROV==131 & CUT_COM!=13115 using "mapa/co_comunas2",
id(id) osize(vvthin vvthin vvthin vvthin vvthin) fcolor(Pastel2) clnumber(5)
ndfcolor(gs15) legend(symy(*0.7) symx(*0.7) size(*1.1) position(7))
legend(title("Puntaje Promedio Matemáticas", size(*0.7) bexpand justification(left)))
ndsize(vvthin) point(data("mapa/rbd_2m2018_pSANTIAGO.dta") xcoord(LONGITUD) ycoord(LATITUD)
                     shape(oh) proportional(prom_mate2m_rbd) osize(vvthin) ocolor(gs8))
label(data("mapa/label_santiago.dta") xcoord(x_coord) ycoord(y_coord) label(COMUNA))
note("Datos de SIMCE 2018.  Cada circulo marca la ubicación exacta de un colegio (y el tamaño representa el puntaje promedio).");
graph export "mapa/rbdSIMCEcom_mat_pSANTIAGO.eps", replace;
#delimit cr


    
