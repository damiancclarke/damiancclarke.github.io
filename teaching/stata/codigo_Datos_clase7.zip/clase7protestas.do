/* clase7protestas.do    analisis economicos y social      yyyy-mm-dd:2021-10-12
----|----1----|----2----|----3----|----4----|----5----|----6----|----7----|----8

Este archivo crea un mapa de protestas de datos del ACLED (de 1 de enero 2021 h-
sta 10 de octubre 2021), y también con datos del PIB del World Bank data bank.
Este archivo requiere varias ados del SSC, indicados en la sección 1 del código.

Nota que en ciertos casos, han habido cambios con los datos descargados utiliz-
ando wbopendata.  En este caso, la línea 43 que dice:
 local wbflag   0
debe ser cambiado a:
 local wbflag   1

Este archivo requiere datos descardos de varias fuentes externas (que veremos
en clases).  Estos son:

https://acleddata.com/#/dashboard

https://mapshaper.org/

http://thematicmapping.org/downloads/world_borders.php
*/

vers 12
clear all
set more off
cap log close

*-------------------------------------------------------------------------------
*-- (1) Globals, check for user-written ados and install if not available
*-------------------------------------------------------------------------------
global DAT "~/trabajo/Teaching/UdeChile/introStata/2021/classes/class7/ejercicio"
global OUT "~/trabajo/Teaching/UdeChile/introStata/2021/classes/class7/ejercicio"
global LOG "~/trabajo/Teaching/UdeChile/introStata/2021/classes/class7/ejercicio"

log using "$LOG/clase7protestas.txt", text replace

local protests 2021-01-01-2021-10-08.csv
local worldmap TM_WORLD_BORDERS_SIMPL-0.shp
local wbflag   1


****Bucle, utilizando "in"
foreach ado in spmap shp2dta wbopendata {
    cap which `ado'
    if _rc!=0 ssc install `ado'
}


*-------------------------------------------------------------------------------
*-- (2) Ejemplos de bucles, condiciones, etc.
*-------------------------------------------------------------------------------
**Versión simple de un foreach con números:
foreach num of numlist 1(1)10 {
    dis `num'
}

**Versión más compleja de un bucle con números:
local suma = 0
forvalues i = 1/10000 {
    if mod(`i',3)==0 {
        dis "`i' es divisible por 3."
        local suma = `suma' + `i'
    }
    else {
        dis "`i' no es divisible por 3."
    }
}
dis "Suma de todos los valores divisibles por 3 entre 1 y 10000 es: `suma'"


sysuse auto
**Versión simple de un foreach con variables:
foreach var of varlist price mpg rep78 headroom {
    gen ln_`var' = log(`var')
    sum `var' ln_`var'
}


**Versión más complejo de un foreach con variables:
foreach var of varlist price-headroom length-displacement {
    sum `var', d
    gen winsor_`var' = `var' if `var'<r(p90)
    replace winsor_`var' = r(p90) if `var'>=r(p90) & `var'!=.
}



*-------------------------------------------------------------------------------
*-- (3) Ejemplo elaborado con ACLED: Importar detos de protestas
*-------------------------------------------------------------------------------
*insheet using 2021-01-01-2021-10-08.csv, comma clear names
insheet using "$DAT/`protests'", comma names clear

keep latitude longitude event_date sub_event_type
saveold "$DAT/protests.dta", replace version(12)


*-------------------------------------------------------------------------------
*-- (3) descargar y procesar datos de PIB
*-------------------------------------------------------------------------------
if `wbflag'==0 {
    wbopendata, indicator(NY.GDP.PCAP.CD) long clear
    keep if year==2018
    drop if iso2code==""
}
else use http://www.damianclarke.net/stata/wbGDPpc2018
saveold "$DAT/wbGDPpc2018", version(12) replace


*-------------------------------------------------------------------------------
*-- (4) Procesar archivos shp
*-------------------------------------------------------------------------------
shp2dta using "$DAT/`worldmap'", data("$DAT/world_data") coor("$DAT/world_coords") replace


*-------------------------------------------------------------------------------
*-- (5) Construir mapas de a poco para llegar a una versión limpia
*-------------------------------------------------------------------------------
use "$DAT/world_data", clear

** Mapa 1 es una mapa simplemente viendo que todo funciona con una variable aleatoria
gen rand=rnormal()

spmap rand using "$DAT/world_coords.dta", id(_ID)
graph export "$OUT/baselineExample.eps", replace


** Mapa 2 genera el mapa utilizando PIB per cápita
use "$DAT/wbGDPpc2018", clear
rename iso2code ISO2
merge 1:1 ISO2 using world_data
drop if _merge==1

spmap ny_gdp_pcap_cd using "$DAT/world_coords.dta" if NAME!="Antartica", id(_ID)
graph export "$OUT/GDPonly.eps", replace
drop if NAME=="Antarctica"


** Mapa 3 agrega datos verdaderos de protestas
#delimit ;
spmap ny_gdp_pcap_cd using world_coords.dta, id(_ID)
   point(data(protests.dta) xcoord(longitude) ycoord(latitude));
graph export "$OUT/GDPwProtests.eps", replace;
#delimit cr


** Mapa 4 lo hace ver más limpio.  Ver archivo help para spmap...
format ny_gdp_pcap_cd %5.0f
graph set eps fontface "Times New Roman"

#delimit ;
spmap ny_gdp_pcap_cd using world_coords.dta, id(_ID)
  point(data(protests.dta) xcoord(longitude) ycoord(latitude) fcolor(red) size(*0.3))
osize(vvthin) fcolor(Pastel2) clnumber(5)
legend(title("PIB per cápita", size(*1.25) bexpand justification(left)))
legend(symy(*1.25) symx(*1.25) size(*1.9)) legstyle(2)
title("PIB per Cápita y Protestas (Enero - Noviembre, 2021)")
note("Fuente: Banco Mundial (datos de PIB) y The Armed Conflict Location & Event Data Project.");
graph export "$OUT/GDPwProtestsClean.eps", replace;
#delimit cr


*-------------------------------------------------------------------------------
*-- (6) Generando mapas temporales
*-------------------------------------------------------------------------------
cap mkdir "$OUT/months"
foreach num of numlist 1(1)10 {
    preserve
    use "$DAT/protests", clear
    gen fecha = date(event_date, "DMY")
    gen month = month(fecha)
    keep if month==`num'
    **extensión: utilizar un archivo temporal para reemplazar la siguiente linea 
    save "$DAT/protests_month", replace
    restore
    
    #delimit ;
    spmap ny_gdp_pcap_cd using world_coords.dta, id(_ID)
    point(data(protests_month.dta) xcoord(longitude) ycoord(latitude) fcolor(red) size(*0.3))
    osize(vvthin) fcolor(Pastel2) clnumber(5)
    legend(title("PIB per cápita", size(*1.25) bexpand justification(left)))
    legend(symy(*1.25) symx(*1.25) size(*1.9)) legstyle(2)
    title("PIB per Cápita and Protests (`num'/2021)")
    note("Fuente: Banco Mundial (PIB) y The Armed Conflict Location & Event Data Project.");
    graph export "$OUT/months/GDPwProtestsClean_`num'.eps", replace;
    #delimit cr
}


** Consideramos varias extensiones:
***** (1) ¿Cómo podríamos tener el mes en el titulo como 01/02/03/.../10/11/12?
***** (2) ¿Cómo podríamos tener el mes como enero, febrero, ... (a partir del bucle)?
***** (3) ¿Cómo podríamos hacer el mismo bucle pero por día?
***** (4) ¿Cómo podríamos hacer un bucle sobre tipos de eventos (event_type)?
    
*-------------------------------------------------------------------------------
*-- (7) Clean up
*-------------------------------------------------------------------------------
log close


